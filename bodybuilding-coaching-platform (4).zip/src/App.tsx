/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { UserProfile, WeightLog, MacroLog, CommunityPost, MembershipTier } from './types';
import { EXERCISE_LIBRARY, COMMUNITY_POSTS, HISTORICAL_WEIGHT_MOCK, HISTORICAL_MACRO_MOCK } from './data';
import OnboardingForm from './components/OnboardingForm';
import WorkoutLogger from './components/WorkoutLogger';
import ShopStore from './components/ShopStore';

// Recharts imports for dashboards
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend
} from 'recharts';

import {
  Dumbbell,
  User,
  ShoppingBag,
  Users,
  BookOpen,
  Plus,
  Flame,
  Droplet,
  Utensils,
  LogOut,
  Trophy,
  Activity,
  Award,
  Search,
  CheckCircle,
  FileText,
  DollarSign,
  ChevronRight,
  Sparkles
} from 'lucide-react';

export default function App() {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'workout' | 'shop' | 'community' | 'library'>('dashboard');
  
  // Historical data
  const [weightHistory, setWeightHistory] = useState<WeightLog[]>([]);
  const [macroHistory, setMacroHistory] = useState<MacroLog[]>([]);
  const [dailyMacros, setDailyMacros] = useState<MacroLog>({
    date: new Date().toISOString().split('T')[0],
    protein: 0,
    carbs: 0,
    fats: 0,
    calories: 0,
    water: 0
  });

  const [communityPosts, setCommunityPosts] = useState<CommunityPost[]>([]);
  const [savedPrs, setSavedPrs] = useState<Array<{ id: string; exercise: string; weight: number; reps: number; date: string }>>([]);

  // Onboarding loading state / Skip Option
  const [isLoading, setIsLoading] = useState(true);

  // Community Inputs
  const [newPostContent, setNewPostContent] = useState('');
  
  // Library search and filters
  const [libSearch, setLibSearch] = useState('');
  const [libFilter, setLibFilter] = useState<'all' | 'chest' | 'back' | 'legs' | 'shoulders' | 'arms' | 'core'>('all');
  const [selectedLibraryEx, setSelectedLibraryEx] = useState<string | null>(null);

  // Quick Macro additions
  const [quickProtein, setQuickProtein] = useState('');
  const [quickCarbs, setQuickCarbs] = useState('');
  const [quickFats, setQuickFats] = useState('');
  const [quickWeightInput, setQuickWeightInput] = useState('');

  // Daily check-in lists
  const [checkedWeightToday, setCheckedWeightToday] = useState(false);
  const [checkedWorkoutToday, setCheckedWorkoutToday] = useState(false);

  // Load from LocalStorage
  useEffect(() => {
    try {
      const storedProfile = localStorage.getItem('athlete_profile');
      const storedWeight = localStorage.getItem('athlete_weight_history');
      const storedMacros = localStorage.getItem('athlete_macro_history');
      const storedDailyMacros = localStorage.getItem('athlete_daily_macros_today');
      const storedPosts = localStorage.getItem('athlete_community_posts');
      const storedPrs = localStorage.getItem('athlete_prs');
      const storedWeightChecked = localStorage.getItem('athlete_weight_checked_today');
      const storedWorkoutChecked = localStorage.getItem('athlete_workout_checked_today');

      if (storedProfile) {
        setProfile(JSON.parse(storedProfile));
      }
      if (storedWeight) {
        setWeightHistory(JSON.parse(storedWeight));
      } else {
        setWeightHistory(HISTORICAL_WEIGHT_MOCK);
      }
      if (storedMacros) {
        setMacroHistory(JSON.parse(storedMacros));
      } else {
        setMacroHistory(HISTORICAL_MACRO_MOCK as any);
      }
      if (storedDailyMacros) {
        const parsed = JSON.parse(storedDailyMacros);
        if (parsed.date === new Date().toISOString().split('T')[0]) {
          setDailyMacros(parsed);
        }
      }
      if (storedPosts) {
        setCommunityPosts(JSON.parse(storedPosts));
      } else {
        setCommunityPosts(COMMUNITY_POSTS);
      }
      if (storedPrs) {
        setSavedPrs(JSON.parse(storedPrs));
      } else {
        // Sample default PRs
        setSavedPrs([
          { id: 'pr-1', exercise: 'Incline Bench Press', weight: 85, reps: 6, date: '2026-06-25' },
          { id: 'pr-2', exercise: 'Barbell Romanian Deadlift', weight: 110, reps: 8, date: '2026-06-28' }
        ]);
      }
      if (storedWeightChecked) setCheckedWeightToday(storedWeightChecked === 'true');
      if (storedWorkoutChecked) setCheckedWorkoutToday(storedWorkoutChecked === 'true');
    } catch (e) {
      console.error('Error parsing localStorage values, fallback to defaults', e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Save to LocalStorage helpers
  const saveProfile = (updated: UserProfile | null) => {
    setProfile(updated);
    if (updated) {
      localStorage.setItem('athlete_profile', JSON.stringify(updated));
    } else {
      localStorage.removeItem('athlete_profile');
    }
  };

  const handleCompleteOnboarding = (completedProfile: UserProfile) => {
    saveProfile(completedProfile);
    setActiveTab('dashboard');
  };

  const loadDemoProfile = () => {
    const demo: UserProfile = {
      name: 'Frank Zane (Demo)',
      email: 'frankzane@aesthetic.com',
      age: 28,
      gender: 'Male',
      height: 178,
      weight: 84.5,
      targetWeight: 81.0,
      bodyFat: 12.5,
      activityLevel: 'active',
      goal: 'cut',
      experienceLevel: 'advanced',
      injuries: 'Slight left wrist soreness during heavy extensions.',
      primaryFocus: 'Upper Chest fullness & Lat width development',
      completedOnboarding: true,
      membershipTier: 'premium',
      macroTargets: {
        protein: 195,
        carbs: 220,
        fats: 65,
        calories: 2245,
        water: 3500
      },
      streakDays: 4
    };
    saveProfile(demo);
    setWeightHistory(HISTORICAL_WEIGHT_MOCK);
    localStorage.setItem('athlete_weight_history', JSON.stringify(HISTORICAL_WEIGHT_MOCK));
    setDailyMacros({
      date: new Date().toISOString().split('T')[0],
      protein: 145,
      carbs: 180,
      fats: 50,
      calories: 1750,
      water: 2500
    });
    localStorage.setItem('athlete_daily_macros_today', JSON.stringify({
      date: new Date().toISOString().split('T')[0],
      protein: 145,
      carbs: 180,
      fats: 50,
      calories: 1750,
      water: 2500
    }));
    setActiveTab('dashboard');
  };

  const handleLogout = () => {
    if (confirm('Are you sure you want to clear your local session? Your stats will reset.')) {
      localStorage.clear();
      setProfile(null);
      setWeightHistory([]);
      setMacroHistory([]);
      setDailyMacros({
        date: new Date().toISOString().split('T')[0],
        protein: 0,
        carbs: 0,
        fats: 0,
        calories: 0,
        water: 0
      });
      setCheckedWeightToday(false);
      setCheckedWorkoutToday(false);
      setActiveTab('dashboard');
    }
  };

  // Log water intake
  const addWater = (ml: number) => {
    const updated = {
      ...dailyMacros,
      water: dailyMacros.water + ml
    };
    setDailyMacros(updated);
    localStorage.setItem('athlete_daily_macros_today', JSON.stringify(updated));
  };

  // Add macro log
  const handleAddMacros = (e: React.FormEvent) => {
    e.preventDefault();
    const p = parseFloat(quickProtein) || 0;
    const c = parseFloat(quickCarbs) || 0;
    const f = parseFloat(quickFats) || 0;
    const cal = p * 4 + c * 4 + f * 9;

    const updated = {
      ...dailyMacros,
      protein: dailyMacros.protein + p,
      carbs: dailyMacros.carbs + c,
      fats: dailyMacros.fats + f,
      calories: dailyMacros.calories + cal
    };
    setDailyMacros(updated);
    localStorage.setItem('athlete_daily_macros_today', JSON.stringify(updated));
    setQuickProtein('');
    setQuickCarbs('');
    setQuickFats('');
  };

  // Add weight checklist log
  const handleLogWeight = (e: React.FormEvent) => {
    e.preventDefault();
    const w = parseFloat(quickWeightInput);
    if (!w) return;

    // Add to chart history
    const todayStr = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    const newWeightLog: WeightLog = {
      date: todayStr,
      weight: w
    };
    const updatedHistory = [...weightHistory, newWeightLog].slice(-10); // Keep last 10
    setWeightHistory(updatedHistory);
    localStorage.setItem('athlete_weight_history', JSON.stringify(updatedHistory));

    // Update current profile weight
    if (profile) {
      const updatedProfile = { ...profile, weight: w };
      saveProfile(updatedProfile);
    }

    setCheckedWeightToday(true);
    localStorage.setItem('athlete_weight_checked_today', 'true');
    setQuickWeightInput('');
  };

  // Handle active workout logging completion
  const handleWorkoutCompletion = (durationMinutes: number) => {
    setCheckedWorkoutToday(true);
    localStorage.setItem('athlete_workout_checked_today', 'true');
    if (profile) {
      const updatedProfile = {
        ...profile,
        streakDays: profile.streakDays + 1
      };
      saveProfile(updatedProfile);
    }
    alert(`⚡ Workout logged! Duration: ${durationMinutes} mins. Your daily bodybuilding split is recorded and streak updated!`);
    setActiveTab('dashboard');
  };

  // Handle PR logging from workout logger
  const handlePrLogged = (exName: string, w: number, r: number) => {
    const newPr = {
      id: 'pr-' + Date.now(),
      exercise: exName,
      weight: w,
      reps: r,
      date: new Date().toISOString().split('T')[0]
    };
    const updated = [newPr, ...savedPrs];
    setSavedPrs(updated);
    localStorage.setItem('athlete_prs', JSON.stringify(updated));
  };

  // Handle plan tier upgrade from subscription module
  const handleUpgradeTier = (tier: MembershipTier) => {
    if (profile) {
      const updated = { ...profile, membershipTier: tier };
      saveProfile(updated);
    }
  };

  // Post in forum
  const handlePostForum = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostContent.trim() || !profile) return;

    const newPost: CommunityPost = {
      id: 'post-user-' + Date.now(),
      author: profile.name,
      role: `Member (${profile.membershipTier.toUpperCase()} Athlete)`,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
      content: newPostContent.trim(),
      likes: 0,
      likedByUser: false,
      timestamp: 'Just now',
      replies: []
    };

    const updated = [newPost, ...communityPosts];
    setCommunityPosts(updated);
    localStorage.setItem('athlete_community_posts', JSON.stringify(updated));
    setNewPostContent('');
  };

  // Like a post
  const handleLikePost = (postId: string) => {
    const updated = communityPosts.map((p) => {
      if (p.id === postId) {
        const liked = !p.likedByUser;
        return {
          ...p,
          likedByUser: liked,
          likes: liked ? p.likes + 1 : p.likes - 1
        };
      }
      return p;
    });
    setCommunityPosts(updated);
    localStorage.setItem('athlete_community_posts', JSON.stringify(updated));
  };

  // Download PDF Report of the user's protocol
  const downloadAestheticProtocolReport = () => {
    if (!profile) return;
    const reportText = `
========================================
   BODYBUILDING PERFORMANCE PLATFORM
       OFFICIAL ANABOLIC PROTOCOL
========================================

CLIENT: ${profile.name}
TARGET PHASING: ${profile.goal.toUpperCase()} PROTOCOL
EXPERIENCE RANKING: ${profile.experienceLevel.toUpperCase()}

ATHLETE DIAGNOSTICS:
- Age: ${profile.age} years
- Height: ${profile.height} cm
- Initial Body Weight: ${profile.weight} kg
- Target Weight Metric: ${profile.targetWeight} kg
- Primary Focus: ${profile.primaryFocus || 'Full Body Symmetry'}
- Injury Profile: ${profile.injuries || 'None'}

CALORIC & MACRONUTRIENT ALLOCATIONS:
- Caloric Ceiling: ${profile.macroTargets.calories} kcal / day
- Protein Benchmark: ${profile.macroTargets.protein} g (High-density)
- Carbohydrate Threshold: ${profile.macroTargets.carbs} g
- Lipids (Fats): ${profile.macroTargets.fats} g
- Hydration Guideline: ${profile.macroTargets.water} ml / day

COACHING REMINDER:
Progressive overload is non-negotiable. Track all training loads, rest times, 
and hydration volume in your active Dashboard.

========================================
      SECURED GATEWAY CERTIFIED
========================================
    `;

    const blob = new Blob([reportText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${profile.name.replace(/\\s+/g, '_')}_protocol.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-neutral-950 flex items-center justify-center text-white font-sans">
        <div className="text-center space-y-3">
          <Dumbbell className="w-12 h-12 text-yellow-500 animate-spin mx-auto" />
          <p className="text-sm text-neutral-400 font-medium">Validating security tokens & state caches...</p>
        </div>
      </div>
    );
  }

  // ONBOARDING GATE
  if (!profile) {
    return (
      <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col justify-center items-center py-12 px-4 relative overflow-hidden font-sans">
        {/* Abstract grids for aesthetic background */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(234,179,8,0.03),transparent)] pointer-events-none" />
        
        <div className="text-center mb-8 max-w-lg space-y-3 relative z-10">
          <div className="inline-flex items-center gap-2 bg-yellow-500/10 border border-yellow-500/20 px-4 py-1.5 rounded-full text-yellow-500 text-xs font-semibold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>ELITE GYM COMPANION PLATFORM</span>
          </div>
          <h1 className="text-4xl font-extrabold tracking-tight text-white font-sans sm:text-5xl">
            Bodybuilding Coaching Platform
          </h1>
          <p className="text-sm text-neutral-400 leading-relaxed">
            Configure your targets, physical parameters, and injuries to unlock tailored muscle splits, macro trackers, and instant PR lockers.
          </p>
        </div>

        <div className="w-full relative z-10">
          <OnboardingForm onComplete={handleCompleteOnboarding} />
        </div>

        <div className="mt-6 flex flex-col items-center gap-2 relative z-10">
          <span className="text-xs text-neutral-500">Just want to explore the platform instantly?</span>
          <button
            onClick={loadDemoProfile}
            className="text-xs text-yellow-500 hover:text-yellow-400 underline decoration-yellow-500/50 hover:decoration-yellow-400 underline-offset-4 font-bold flex items-center gap-1 bg-yellow-500/5 px-4 py-2 rounded-lg border border-yellow-500/10"
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Load Demo Athlete Profile</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 font-sans flex flex-col justify-between">
      {/* HEADER BAR */}
      <header className="bg-neutral-900/90 backdrop-blur-md border-b border-neutral-800/80 sticky top-0 z-40 px-6 py-4 flex items-center justify-between" id="app-header">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-yellow-500 text-black rounded-lg flex items-center justify-center font-black shadow-lg shadow-yellow-500/15">
            <Dumbbell className="w-5 h-5" />
          </div>
          <div>
            <span className="block text-sm font-black tracking-tight text-white font-sans uppercase">ANABOLIC ECOSYSTEM</span>
            <span className="text-[10px] text-yellow-500 uppercase font-semibold tracking-wider">BODYBUILDING COMPANION</span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="hidden md:flex items-center gap-1.5 bg-neutral-950 p-1 rounded-xl border border-neutral-800/80">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: Activity },
            { id: 'workout', label: 'Workout Logger', icon: Dumbbell },
            { id: 'shop', label: 'E-Commerce Store', icon: ShoppingBag },
            { id: 'community', label: 'Community Feed', icon: Users },
            { id: 'library', label: 'Exercise Vault', icon: BookOpen },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 rounded-lg text-xs font-bold uppercase transition-all flex items-center gap-2 ${
                  activeTab === tab.id
                    ? 'bg-yellow-500 text-black shadow-lg'
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>

        {/* User Stats & Logout */}
        <div className="flex items-center gap-4">
          <div className="text-right hidden sm:block">
            <span className="block text-xs font-bold text-white">{profile.name}</span>
            <span className="text-[10px] bg-yellow-500/15 text-yellow-400 border border-yellow-500/30 px-2 py-0.5 rounded-full font-bold uppercase">
              {profile.membershipTier} Member
            </span>
          </div>

          <button
            onClick={handleLogout}
            className="p-2 rounded-lg border border-neutral-800 text-neutral-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
            title="Reset Session"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* MOBILE NAV FOOTER */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-neutral-900 border-t border-neutral-800 z-40 px-4 py-2 flex justify-around">
        {[
          { id: 'dashboard', label: 'Stats', icon: Activity },
          { id: 'workout', label: 'Workout', icon: Dumbbell },
          { id: 'shop', label: 'Shop', icon: ShoppingBag },
          { id: 'community', label: 'Social', icon: Users },
          { id: 'library', label: 'Library', icon: BookOpen },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex flex-col items-center gap-1 p-1.5 rounded-lg transition-colors ${
                activeTab === tab.id ? 'text-yellow-500' : 'text-neutral-500'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-[9px] font-bold uppercase tracking-wider">{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* MAIN CONTAINER */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-6 py-8 pb-24 md:pb-12">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {/* TAB 1: INTERACTIVE DASHBOARD */}
            {activeTab === 'dashboard' && (
              <div className="space-y-8">
                {/* HERO STRIP */}
                <div className="bg-gradient-to-r from-neutral-900 via-neutral-900 to-yellow-500/5 border border-neutral-800 rounded-2xl p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                  <div className="space-y-2">
                    <h1 className="text-2xl font-black text-white tracking-tight sm:text-3xl font-sans">
                      Aesthetic Diagnostics Protocol
                    </h1>
                    <p className="text-sm text-neutral-400 max-w-xl">
                      Welcome back, athlete. You are currently on an <strong className="text-yellow-500 font-semibold">{profile.goal.toUpperCase()}</strong> calorie phase targeting <strong className="text-white font-medium">{profile.macroTargets.calories} kcal</strong> daily. Keep tracking parameters to preserve muscle integrity.
                    </p>
                    <div className="flex flex-wrap gap-2 pt-1">
                      <span className="bg-neutral-950 border border-neutral-800 px-3 py-1 rounded-full text-xs text-neutral-300">
                        Weight: <strong className="text-white">{profile.weight}kg</strong> (Target: {profile.targetWeight}kg)
                      </span>
                      <span className="bg-neutral-950 border border-neutral-800 px-3 py-1 rounded-full text-xs text-neutral-300">
                        Experience: <strong className="text-white capitalize">{profile.experienceLevel}</strong>
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={downloadAestheticProtocolReport}
                    className="px-5 py-2.5 bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 rounded-lg hover:bg-yellow-500/20 transition-all text-xs font-bold uppercase flex items-center gap-2"
                  >
                    <FileText className="w-4 h-4" />
                    <span>Download Report</span>
                  </button>
                </div>

                {/* THREE COLUMN GRID: CHECKLIST, INPUTS, QUICK CHART */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* COLUMN 1: DAILY TARGETS & LOGGING */}
                  <div className="space-y-6">
                    {/* DAILY TASK CHECKLIST */}
                    <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-4">
                      <h3 className="text-sm font-bold text-white uppercase tracking-wider font-sans">Daily Check-In Metrics</h3>
                      
                      <div className="space-y-3">
                        {/* Task 1 */}
                        <div className="flex items-center justify-between p-3 bg-neutral-950 rounded-xl border border-neutral-800/60">
                          <div>
                            <span className="block text-xs font-bold text-white">Scale Weight Log</span>
                            <span className="text-[10px] text-neutral-400">Record daily weight to feed charts</span>
                          </div>
                          {checkedWeightToday ? (
                            <span className="text-xs text-emerald-400 bg-emerald-400/10 border border-emerald-400/20 px-2.5 py-1 rounded-full font-bold flex items-center gap-1">
                              <CheckCircle className="w-3.5 h-3.5" />
                              <span>DONE</span>
                            </span>
                          ) : (
                            <span className="text-xs text-yellow-500 bg-yellow-500/10 border border-yellow-500/20 px-2.5 py-1 rounded-full font-bold animate-pulse">
                              PENDING
                            </span>
                          )}
                        </div>

                        {/* Task 2 */}
                        <div className="flex items-center justify-between p-3 bg-neutral-950 rounded-xl border border-neutral-800/60">
                          <div>
                            <span className="block text-xs font-bold text-white">Daily Workout Routine</span>
                            <span className="text-[10px] text-neutral-400">Mark sets completed in logger</span>
                          </div>
                          {checkedWorkoutToday ? (
                            <span className="text-xs text-emerald-400 bg-emerald-400/10 border border-emerald-400/20 px-2.5 py-1 rounded-full font-bold flex items-center gap-1">
                              <CheckCircle className="w-3.5 h-3.5" />
                              <span>LOGGED</span>
                            </span>
                          ) : (
                            <span className="text-xs text-yellow-500 bg-yellow-500/10 border border-yellow-500/20 px-2.5 py-1 rounded-full font-bold">
                              PENDING
                            </span>
                          )}
                        </div>

                        {/* Task 3 */}
                        <div className="flex items-center justify-between p-3 bg-neutral-950 rounded-xl border border-neutral-800/60">
                          <div>
                            <span className="block text-xs font-bold text-white">Hydration Baseline</span>
                            <span className="text-[10px] text-neutral-400">Aim for: {profile.macroTargets.water} ml</span>
                          </div>
                          <div className="text-right">
                            <span className="block text-xs font-mono font-bold text-white">{dailyMacros.water} / {profile.macroTargets.water} ml</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* WATER TRACKING INTERACTIVE */}
                    <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-bold text-white uppercase tracking-wider font-sans">Interactive Hydrator</h3>
                        <Droplet className="w-5 h-5 text-blue-500" />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() => addWater(250)}
                          className="py-2.5 bg-neutral-950 border border-neutral-800 hover:border-blue-500 hover:bg-blue-500/5 text-xs font-bold rounded-xl transition-all"
                        >
                          +250ml Glass
                        </button>
                        <button
                          onClick={() => addWater(1000)}
                          className="py-2.5 bg-neutral-950 border border-neutral-800 hover:border-blue-500 hover:bg-blue-500/5 text-xs font-bold rounded-xl transition-all"
                        >
                          +1000ml Shaker
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* COLUMN 2: METRICS INTAKE FORM */}
                  <div className="space-y-6">
                    {/* QUANTITATIVE MACRO INTAKE LOG */}
                    <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-bold text-white uppercase tracking-wider font-sans">Quick Food Log</h3>
                        <Utensils className="w-4 h-4 text-yellow-500" />
                      </div>

                      <form onSubmit={handleAddMacros} className="space-y-3">
                        <div className="grid grid-cols-3 gap-2">
                          <div>
                            <label className="block text-[10px] text-neutral-500 uppercase font-bold mb-1">Protein (g)</label>
                            <input
                              type="number"
                              value={quickProtein}
                              onChange={(e) => setQuickProtein(e.target.value)}
                              placeholder="e.g. 35"
                              className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg p-2 text-xs focus:outline-none focus:border-yellow-500 font-mono"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-neutral-500 uppercase font-bold mb-1">Carbs (g)</label>
                            <input
                              type="number"
                              value={quickCarbs}
                              onChange={(e) => setQuickCarbs(e.target.value)}
                              placeholder="e.g. 50"
                              className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg p-2 text-xs focus:outline-none focus:border-yellow-500 font-mono"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-neutral-500 uppercase font-bold mb-1">Fats (g)</label>
                            <input
                              type="number"
                              value={quickFats}
                              onChange={(e) => setQuickFats(e.target.value)}
                              placeholder="e.g. 10"
                              className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg p-2 text-xs focus:outline-none focus:border-yellow-500 font-mono"
                            />
                          </div>
                        </div>

                        <button
                          type="submit"
                          className="w-full py-2 bg-yellow-500 text-black text-[11px] font-bold uppercase rounded-lg hover:bg-yellow-400 transition-colors"
                        >
                          Inject Macro Log
                        </button>
                      </form>
                    </div>

                    {/* QUANTITATIVE SCALE WEIGHT LOG */}
                    <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-4">
                      <h3 className="text-sm font-bold text-white uppercase tracking-wider font-sans">Scale Weight Calibration</h3>
                      
                      <form onSubmit={handleLogWeight} className="flex gap-2">
                        <input
                          type="number"
                          step="0.1"
                          required
                          value={quickWeightInput}
                          onChange={(e) => setQuickWeightInput(e.target.value)}
                          placeholder="e.g. 84.1"
                          className="flex-1 bg-neutral-950 border border-neutral-800 text-white rounded-lg px-3.5 py-2 text-xs focus:outline-none focus:border-yellow-500 font-mono"
                        />
                        <button
                          type="submit"
                          className="px-4 bg-neutral-800 border border-neutral-700 text-white rounded-lg text-xs font-bold hover:bg-neutral-700"
                        >
                          Log Weight
                        </button>
                      </form>
                    </div>
                  </div>

                  {/* COLUMN 3: TRANSFORMATION OF THE MONTH SPOTLIGHT */}
                  <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-4">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-yellow-500 bg-yellow-500/10 border border-yellow-500/20 px-2.5 py-0.5 rounded-full inline-block">
                      TRANSFORMATION HIGHLIGHT
                    </span>
                    <h3 className="text-base font-bold text-white leading-snug">Alex Carter's 8-Week Cut</h3>
                    
                    <div className="grid grid-cols-2 gap-2">
                      <div className="relative h-44 rounded-xl overflow-hidden bg-neutral-950 border border-neutral-800">
                        <img
                          src="https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=300&q=80"
                          alt="Before"
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                        <span className="absolute bottom-2 left-2 bg-black/70 text-[9px] font-bold px-1.5 py-0.5 rounded text-yellow-500 border border-yellow-500/20 uppercase">BEFORE (91kg)</span>
                      </div>
                      <div className="relative h-44 rounded-xl overflow-hidden bg-neutral-950 border border-neutral-800">
                        <img
                          src="https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?auto=format&fit=crop&w=300&q=80"
                          alt="After"
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                        <span className="absolute bottom-2 left-2 bg-black/70 text-[9px] font-bold px-1.5 py-0.5 rounded text-emerald-400 border border-emerald-400/20 uppercase">AFTER (84kg)</span>
                      </div>
                    </div>

                    <p className="text-[11px] text-neutral-400 leading-relaxed italic">
                      "I hit standard hypertrophy parameters consistently and restricted caloric levels under Marcus's Gold protocol. Kept my mass intact!"
                    </p>
                  </div>
                </div>

                {/* VISUAL ANALYTICS SECTION */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* CHART 1: SCALE WEIGHT HISTORY */}
                  <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-4">
                    <div>
                      <h3 className="text-base font-bold text-white">Scale Weight Over Time</h3>
                      <p className="text-xs text-neutral-400">Tracking dry lean weight shifts across training block.</p>
                    </div>

                    <div className="h-64 w-full bg-neutral-950 rounded-xl p-2 border border-neutral-800/40">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={weightHistory}>
                          <defs>
                            <linearGradient id="weightGrad" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#eab308" stopOpacity={0.2} />
                              <stop offset="95%" stopColor="#eab308" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#262626" />
                          <XAxis dataKey="date" stroke="#737373" fontSize={10} />
                          <YAxis domain={['dataMin - 1', 'dataMax + 1']} stroke="#737373" fontSize={10} />
                          <Tooltip contentStyle={{ backgroundColor: '#171717', borderColor: '#262626', color: '#fff', fontSize: '11px' }} />
                          <Area type="monotone" dataKey="weight" stroke="#eab308" strokeWidth={2} fillOpacity={1} fill="url(#weightGrad)" />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* CHART 2: DAILY MACROS vs TARGET */}
                  <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-4">
                    <div>
                      <h3 className="text-base font-bold text-white">Daily Macronutrient Load</h3>
                      <p className="text-xs text-neutral-400">Actual consumption vs. calculated target values.</p>
                    </div>

                    <div className="h-64 w-full bg-neutral-950 rounded-xl p-2 border border-neutral-800/40">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={[
                            { name: 'Protein (g)', Logged: dailyMacros.protein, Target: profile.macroTargets.protein },
                            { name: 'Carbs (g)', Logged: dailyMacros.carbs, Target: profile.macroTargets.carbs },
                            { name: 'Fats (g)', Logged: dailyMacros.fats, Target: profile.macroTargets.fats }
                          ]}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke="#262626" />
                          <XAxis dataKey="name" stroke="#737373" fontSize={10} />
                          <YAxis stroke="#737373" fontSize={10} />
                          <Tooltip contentStyle={{ backgroundColor: '#171717', borderColor: '#262626', color: '#fff', fontSize: '11px' }} />
                          <Legend wrapperStyle={{ fontSize: '10px' }} />
                          <Bar dataKey="Logged" fill="#eab308" radius={[4, 4, 0, 0]} />
                          <Bar dataKey="Target" fill="#404040" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: ACTIVE WORKOUT LOGGER */}
            {activeTab === 'workout' && (
              <div className="space-y-6">
                <WorkoutLogger
                  goal={profile.goal}
                  streakDays={profile.streakDays}
                  onWorkoutComplete={handleWorkoutCompletion}
                  onPrLogged={handlePrLogged}
                  savedPrs={savedPrs}
                />
              </div>
            )}

            {/* TAB 3: SUBSCRIPTION & STORE */}
            {activeTab === 'shop' && (
              <ShopStore
                currentTier={profile.membershipTier}
                onUpgradeTier={handleUpgradeTier}
              />
            )}

            {/* TAB 4: COMMUNITY & TESTIMONIALS */}
            {activeTab === 'community' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* FORUM AND DISCUSSIONS SECTION */}
                <div className="lg:col-span-2 space-y-6">
                  <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-4">
                    <h2 className="text-xl font-bold text-white tracking-tight font-sans">Athlete Community Forum</h2>
                    <p className="text-xs text-neutral-400">Share tips, progress reports, and seek advice from IFBB Pro coaches.</p>

                    {/* Post submission */}
                    <form onSubmit={handlePostForum} className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 space-y-3">
                      <textarea
                        required
                        value={newPostContent}
                        onChange={(e) => setNewPostContent(e.target.value)}
                        placeholder="Share a PR, pose update, or dynamic training query..."
                        rows={3}
                        className="w-full bg-transparent text-xs text-white placeholder-neutral-500 focus:outline-none resize-none"
                      />
                      <div className="flex justify-between items-center pt-2 border-t border-neutral-800/60">
                        <span className="text-[10px] text-neutral-500 font-medium">Posting securely as {profile.name}</span>
                        <button
                          type="submit"
                          className="px-4 py-1.5 bg-yellow-500 text-black text-xs font-bold rounded-lg hover:bg-yellow-400"
                        >
                          Post Update
                        </button>
                      </div>
                    </form>
                  </div>

                  {/* Feed thread */}
                  <div className="space-y-4">
                    {communityPosts.map((post) => (
                      <div key={post.id} className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 space-y-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={post.avatar}
                            alt={post.author}
                            referrerPolicy="no-referrer"
                            className="w-10 h-10 rounded-full border border-neutral-800 object-cover"
                          />
                          <div>
                            <span className="block text-sm font-bold text-white">{post.author}</span>
                            <span className="text-[10px] text-yellow-500 font-semibold">{post.role}</span>
                          </div>
                          <span className="text-[10px] text-neutral-500 ml-auto font-medium">{post.timestamp}</span>
                        </div>

                        <p className="text-xs text-neutral-300 leading-relaxed">{post.content}</p>

                        <div className="flex items-center gap-4 pt-2 border-t border-neutral-800/40">
                          <button
                            onClick={() => handleLikePost(post.id)}
                            className={`text-xs font-bold flex items-center gap-1 ${
                              post.likedByUser ? 'text-yellow-500' : 'text-neutral-500 hover:text-neutral-300'
                            }`}
                          >
                            <span>🔥 Likes ({post.likes})</span>
                          </button>
                          
                          <span className="text-xs text-neutral-500 font-bold">💬 Replies ({post.replies?.length || 0})</span>
                        </div>

                        {/* Replies */}
                        {post.replies && post.replies.length > 0 && (
                          <div className="bg-neutral-950/60 border border-neutral-800/60 rounded-xl p-3 space-y-3">
                            {post.replies.map((rep) => (
                              <div key={rep.id} className="text-xs space-y-0.5 pb-2 border-b border-neutral-900 last:border-0 last:pb-0">
                                <div className="flex items-center justify-between">
                                  <span className="font-bold text-neutral-200">{rep.author}</span>
                                  <span className="text-[9px] text-neutral-500">{rep.timestamp}</span>
                                </div>
                                <p className="text-[11px] text-neutral-400">{rep.content}</p>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* TESTIMONIAL CAROUSEL & SOCIAL FEEDS */}
                <div className="space-y-6">
                  {/* INSTAGRAM SIMULATOR REEL */}
                  <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-4">
                    <span className="text-[10px] text-yellow-500 font-bold uppercase tracking-widest bg-yellow-500/10 border border-yellow-500/20 px-2 py-0.5 rounded-full inline-block">
                      INSTAGRAM SOCIAL FEED
                    </span>
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider font-sans">Anabolic Inspiration</h3>

                    <div className="grid grid-cols-2 gap-2">
                      {[
                        'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=300&q=80',
                        'https://images.unsplash.com/photo-1548690312-e3b507d8c110?auto=format&fit=crop&w=300&q=80',
                        'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?auto=format&fit=crop&w=300&q=80',
                        'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=300&q=80'
                      ].map((img, idx) => (
                        <div key={idx} className="relative aspect-square rounded-xl overflow-hidden bg-neutral-950 border border-neutral-800 hover:scale-102 transition-transform cursor-pointer">
                          <img
                            src={img}
                            referrerPolicy="no-referrer"
                            alt="Social"
                            className="w-full h-full object-cover"
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* HALL OF TESTIMONIALS */}
                  <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-4">
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider font-sans">Hall of Testimonials</h3>
                    
                    <div className="space-y-4">
                      {[
                        { name: 'Sarah Jenkins', loss: '-12kg Fat', quote: 'The training database is unmatched. I love how simple it is to log sets.' },
                        { name: 'David Miller', loss: '+6kg Lean Mass', quote: 'The instant calorie diagnostics is spot on. Saved me hours of math.' }
                      ].map((t, idx) => (
                        <div key={idx} className="bg-neutral-950/80 border border-neutral-800/80 rounded-xl p-4.5 space-y-1.5">
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-white text-xs">{t.name}</span>
                            <span className="bg-emerald-500/15 border border-emerald-500/20 text-emerald-400 text-[10px] px-2 py-0.2 rounded font-bold">{t.loss}</span>
                          </div>
                          <p className="text-[11px] text-neutral-400 leading-normal">"{t.quote}"</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 5: VIDEO EXERCISE LIBRARY */}
            {activeTab === 'library' && (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-2xl font-bold text-white tracking-tight font-sans">Biomechanical Exercise Vault</h2>
                    <p className="text-sm text-neutral-400">Scientifically engineered exercise execution parameters to isolate specific muscle fibers.</p>
                  </div>

                  <div className="flex items-center gap-2 bg-neutral-900 border border-neutral-800/80 p-1.5 rounded-xl self-start sm:self-center">
                    {(['all', 'chest', 'back', 'legs', 'shoulders', 'arms'] as const).map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setLibFilter(cat)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase transition-all ${
                          libFilter === cat
                            ? 'bg-yellow-500 text-black'
                            : 'text-neutral-400 hover:text-white'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* SEARCH INPUT */}
                <div className="relative">
                  <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    value={libSearch}
                    onChange={(e) => setLibSearch(e.target.value)}
                    placeholder="Search movement mechanics..."
                    className="w-full bg-neutral-900 border border-neutral-800 text-xs text-white pl-10 pr-4 py-3 rounded-xl focus:outline-none focus:border-yellow-500 transition-colors"
                  />
                </div>

                {/* LIBRARY GRID AND PREVIEW PANEL */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {/* MASTER LIST (2 COLUMNS IN DESKTOP) */}
                  <div className="md:col-span-2 space-y-3 max-h-[600px] overflow-y-auto pr-2">
                    {EXERCISE_LIBRARY
                      .filter((ex) => libFilter === 'all' || ex.category === libFilter)
                      .filter((ex) => ex.name.toLowerCase().includes(libSearch.toLowerCase()))
                      .map((ex) => (
                        <div
                          key={ex.id}
                          onClick={() => setSelectedLibraryEx(ex.id)}
                          className={`p-4 bg-neutral-900 border rounded-xl cursor-pointer text-left transition-all ${
                            selectedLibraryEx === ex.id
                              ? 'border-yellow-500 bg-yellow-500/5'
                              : 'border-neutral-800 hover:border-neutral-700'
                          }`}
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-bold text-white text-sm">{ex.name}</h4>
                              <p className="text-xs text-neutral-400 mt-1 line-clamp-1">{ex.description}</p>
                            </div>
                            <span className="text-[10px] bg-neutral-950 border border-neutral-800 text-neutral-400 px-2 py-0.5 rounded font-mono uppercase">
                              {ex.category}
                            </span>
                          </div>

                          <div className="flex gap-1.5 pt-3">
                            {ex.targetMuscles.map((m) => (
                              <span key={m} className="bg-neutral-950 text-[9px] text-neutral-400 border border-neutral-800 px-2 py-0.5 rounded">
                                {m}
                              </span>
                            ))}
                          </div>
                        </div>
                      ))}
                  </div>

                  {/* PREVIEW PANEL */}
                  <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 h-fit">
                    {selectedLibraryEx ? (
                      (() => {
                        const item = EXERCISE_LIBRARY.find((ex) => ex.id === selectedLibraryEx);
                        if (!item) return null;
                        return (
                          <div className="space-y-4">
                            <span className="text-[10px] bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 px-2 py-0.5 rounded font-bold uppercase inline-block">
                              {item.category} • {item.difficulty}
                            </span>
                            <h3 className="text-base font-bold text-white font-sans">{item.name}</h3>
                            <p className="text-xs text-neutral-400 leading-relaxed">{item.description}</p>

                            <div className="space-y-1.5">
                              <span className="block text-[10px] font-bold text-neutral-500 uppercase tracking-wider">Target Fibers</span>
                              <div className="flex flex-wrap gap-1">
                                {item.targetMuscles.map((m) => (
                                  <span key={m} className="bg-neutral-950 text-xs text-white border border-neutral-800/80 px-2.5 py-0.5 rounded-lg">
                                    {m}
                                  </span>
                                ))}
                              </div>
                            </div>

                            <div className="space-y-2 pt-2 border-t border-neutral-800/60">
                              <span className="block text-[10px] font-bold text-neutral-500 uppercase tracking-wider">Coaches execution step list</span>
                              <ol className="list-decimal pl-4.5 text-[11px] text-neutral-300 space-y-2">
                                {item.instructions.map((inst, i) => (
                                  <li key={i} className="leading-relaxed">
                                    {inst}
                                  </li>
                                ))}
                              </ol>
                            </div>
                          </div>
                        );
                      })()
                    ) : (
                      <div className="text-center py-12 space-y-2 text-neutral-500">
                        <BookOpen className="w-8 h-8 mx-auto text-neutral-600" />
                        <span className="block text-xs font-bold uppercase">Select an exercise</span>
                        <span className="text-[10px]">Tap on any movement in the vault list to pull biomechanical guides.</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* FOOTER BAR */}
      <footer className="bg-neutral-900/60 border-t border-neutral-800/40 py-6 px-6 text-center text-[11px] text-neutral-500 space-y-2">
        <p>Aesthetics Anabolic Ecosystem © 2026. Certified SSL Encrypted. HIPAA & GDPR Compliant Data Shielding.</p>
        <div className="flex justify-center gap-4 text-neutral-600">
          <span>Secure Guest Checkout Enabled</span>
          <span>•</span>
          <span>Direct Webhook Payment Verification</span>
          <span>•</span>
          <span>IFBB Certified Coaching</span>
        </div>
      </footer>
    </div>
  );
}
