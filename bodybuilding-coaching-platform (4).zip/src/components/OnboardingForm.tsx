/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { UserProfile, FitnessGoal, ExperienceLevel } from '../types';
import { Dumbbell, ArrowRight, ArrowLeft, Check, Sparkles, AlertCircle, Upload } from 'lucide-react';

interface OnboardingFormProps {
  onComplete: (profile: UserProfile) => void;
}

export default function OnboardingForm({ onComplete }: OnboardingFormProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    age: 25,
    gender: 'Male',
    height: 180, // cm
    weight: 80, // kg
    targetWeight: 85, // kg
    bodyFat: 15,
    activityLevel: 'moderate' as UserProfile['activityLevel'],
    goal: 'bulk' as FitnessGoal,
    experienceLevel: 'intermediate' as ExperienceLevel,
    injuries: '',
    primaryFocus: 'Hypertrophy & Aesthetics',
  });

  const [dragActive, setDragActive] = useState(false);
  const [photoUploaded, setPhotoUploaded] = useState(false);
  const [error, setError] = useState('');

  const nextStep = () => {
    if (step === 1 && (!formData.name || !formData.email)) {
      setError('Please fill in your name and email to proceed.');
      return;
    }
    setError('');
    setStep((prev) => prev + 1);
  };

  const prevStep = () => {
    setError('');
    setStep((prev) => prev - 1);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: ['age', 'height', 'weight', 'targetWeight', 'bodyFat'].includes(name)
        ? parseFloat(value) || 0
        : value,
    }));
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setPhotoUploaded(true);
    }
  };

  const calculateMacros = () => {
    const { weight, goal, activityLevel, height, age, gender } = formData;
    
    // Simple Harris-Benedict formula base BMR estimate
    let bmr = 10 * weight + 6.25 * height - 5 * age;
    bmr = gender === 'Male' ? bmr + 5 : bmr - 161;

    // Activity multiplier
    const multipliers = {
      sedentary: 1.2,
      light: 1.375,
      moderate: 1.55,
      active: 1.725,
      very_active: 1.9,
    };
    const tdee = Math.round(bmr * (multipliers[activityLevel] || 1.55));

    let calories = tdee;
    let proteinMultiplier = 2.2; // 2.2g per kg (1g per lb)
    let fatPercentage = 0.25; // 25% of calories

    if (goal === 'bulk') {
      calories = tdee + 400; // Caloric surplus for muscle growth
      proteinMultiplier = 2.2;
      fatPercentage = 0.25;
    } else if (goal === 'cut') {
      calories = tdee - 500; // Caloric deficit for fat loss
      proteinMultiplier = 2.4; // Slightly higher protein to preserve muscle
      fatPercentage = 0.22;
    } else {
      // Recomposition
      calories = tdee - 100;
      proteinMultiplier = 2.3;
      fatPercentage = 0.24;
    }

    const protein = Math.round(weight * proteinMultiplier);
    const proteinCalories = protein * 4;
    const fatCalories = Math.round(calories * fatPercentage);
    const fats = Math.round(fatCalories / 9);
    const carbCalories = calories - (proteinCalories + fatCalories);
    const carbs = Math.round(carbCalories / 4);
    const water = Math.round(weight * 35); // 35ml per kg base

    return {
      protein,
      carbs,
      fats,
      calories,
      water,
    };
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const macros = calculateMacros();
    const completedProfile: UserProfile = {
      ...formData,
      completedOnboarding: true,
      membershipTier: 'premium', // Default tier given during onboarding simulation
      macroTargets: macros,
      streakDays: 1,
    };
    onComplete(completedProfile);
  };

  return (
    <div className="w-full max-w-2xl mx-auto bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden shadow-2xl" id="onboarding-card">
      {/* Upper header */}
      <div className="bg-gradient-to-r from-yellow-500/10 via-amber-500/5 to-neutral-900 px-8 py-6 border-b border-neutral-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-yellow-500/10 flex items-center justify-center border border-yellow-500/20 text-yellow-500">
            <Dumbbell className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h1 className="text-lg font-semibold tracking-tight text-white font-sans">Coaching Onboarding</h1>
            <p className="text-xs text-neutral-400">Step {step} of 4 • Tailoring your elite fitness blueprint</p>
          </div>
        </div>
        <div className="flex gap-1">
          {[1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className={`h-1.5 w-6 rounded-full transition-all duration-300 ${
                i <= step ? 'bg-yellow-500' : 'bg-neutral-800'
              }`}
            />
          ))}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="p-8">
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 p-4 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 flex items-center gap-3 text-sm"
          >
            <AlertCircle className="w-4 h-4" />
            <span>{error}</span>
          </motion.div>
        )}

        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div>
                <h2 className="text-xl font-medium text-white mb-2">Let's start with the basics</h2>
                <p className="text-sm text-neutral-400">We need your name and details to setup your athlete account.</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-1.5">Full Name</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="e.g., Arnold Schwarzenegger"
                    required
                    className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-yellow-500 transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-1.5">Email Address</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="e.g., arnold@gym.com"
                    required
                    className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-yellow-500 transition-colors"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-1.5">Age</label>
                    <input
                      type="number"
                      name="age"
                      value={formData.age}
                      onChange={handleChange}
                      min="16"
                      max="100"
                      className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-yellow-500 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-1.5">Gender ID</label>
                    <select
                      name="gender"
                      value={formData.gender}
                      onChange={handleChange}
                      className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-yellow-500 transition-colors"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Non-binary">Non-binary</option>
                    </select>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div>
                <h2 className="text-xl font-medium text-white mb-2">Physique Targets & Experience</h2>
                <p className="text-sm text-neutral-400">Your specific stats define the mathematical baseline of your diet and routine.</p>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-1.5">Height (cm)</label>
                    <input
                      type="number"
                      name="height"
                      value={formData.height}
                      onChange={handleChange}
                      min="100"
                      max="250"
                      className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-yellow-500 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-1.5">Weight (kg)</label>
                    <input
                      type="number"
                      name="weight"
                      value={formData.weight}
                      onChange={handleChange}
                      min="30"
                      max="250"
                      className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-yellow-500 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-1.5">Target (kg)</label>
                    <input
                      type="number"
                      name="targetWeight"
                      value={formData.targetWeight}
                      onChange={handleChange}
                      min="30"
                      max="250"
                      className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-yellow-500 transition-colors"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-1.5">Body Fat % (Est.)</label>
                    <input
                      type="number"
                      name="bodyFat"
                      value={formData.bodyFat}
                      onChange={handleChange}
                      min="4"
                      max="50"
                      className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-yellow-500 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-1.5">Experience Level</label>
                    <select
                      name="experienceLevel"
                      value={formData.experienceLevel}
                      onChange={handleChange}
                      className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-yellow-500 transition-colors"
                    >
                      <option value="beginner">Beginner (&lt; 1 Year)</option>
                      <option value="intermediate">Intermediate (1-4 Years)</option>
                      <option value="advanced">Advanced (4+ Years, Competitor)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-2">Primary Goal</label>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { id: 'bulk', name: 'Mass Gain (Bulk)', desc: 'Surplus calories & heavy compounds to add maximum hypertrophy.' },
                      { id: 'cut', name: 'Fat Shred (Cut)', desc: 'Deficit calories optimized to preserve lean tissue and melt fat.' },
                      { id: 'recomp', name: 'Recomposition', desc: 'Simultaneous fat loss and muscle gain (ideal for intermediates).' },
                    ].map((g) => (
                      <div
                        key={g.id}
                        onClick={() => setFormData(prev => ({ ...prev, goal: g.id as FitnessGoal }))}
                        className={`p-4 border rounded-xl cursor-pointer text-left transition-all duration-200 hover:border-yellow-500/50 ${
                          formData.goal === g.id
                            ? 'bg-yellow-500/10 border-yellow-500 text-white shadow-lg'
                            : 'bg-neutral-950 border-neutral-800 text-neutral-300'
                        }`}
                      >
                        <h4 className="text-sm font-medium mb-1">{g.name}</h4>
                        <p className="text-[11px] leading-relaxed text-neutral-400">{g.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div>
                <h2 className="text-xl font-medium text-white mb-2">Health, Capacity & Activity</h2>
                <p className="text-sm text-neutral-400">Ensure safety and set up volume constraints.</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-1.5">Activity Multiplier</label>
                  <select
                    name="activityLevel"
                    value={formData.activityLevel}
                    onChange={handleChange}
                    className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-yellow-500 transition-colors"
                  >
                    <option value="sedentary">Sedentary (Office job, minimal exercise)</option>
                    <option value="light">Lightly Active (1-3 days weight training/week)</option>
                    <option value="moderate">Moderately Active (3-5 days intense lift/week)</option>
                    <option value="active">Active (Daily heavy lifts + general physical job)</option>
                    <option value="very_active">Very Active (Elite athlete double sessions, construction, etc.)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-1.5">Primary Focus Area</label>
                  <input
                    type="text"
                    name="primaryFocus"
                    value={formData.primaryFocus}
                    onChange={handleChange}
                    placeholder="e.g., Lagging shoulders/back thickness, chest mass"
                    className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-yellow-500 transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-1.5">Injury & Medical History (If Any)</label>
                  <textarea
                    name="injuries"
                    value={formData.injuries}
                    onChange={handleChange}
                    rows={3}
                    placeholder="e.g., Lower back disc issues, shoulder impingement on bench press (Leave blank if none)"
                    className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-yellow-500 transition-colors resize-none"
                  />
                </div>
              </div>
            </motion.div>
          )}

          {step === 4 && (
            <motion.div
              key="step4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div>
                <h2 className="text-xl font-medium text-white mb-2">Upload Base Photo & Review</h2>
                <p className="text-sm text-neutral-400">Establish a baseline to track visual progress.</p>
              </div>

              <div className="space-y-4">
                {/* Drag and Drop Box */}
                <div
                  onDragEnter={handleDrag}
                  onDragOver={handleDrag}
                  onDragLeave={handleDrag}
                  onDrop={handleDrop}
                  className={`border-2 border-dashed rounded-xl p-6 text-center transition-all ${
                    dragActive
                      ? 'border-yellow-500 bg-yellow-500/5'
                      : photoUploaded
                      ? 'border-emerald-500 bg-emerald-500/5'
                      : 'border-neutral-800 bg-neutral-950'
                  }`}
                >
                  <input
                    type="file"
                    id="photo-upload"
                    className="hidden"
                    accept="image/*"
                    onChange={() => setPhotoUploaded(true)}
                  />
                  <label htmlFor="photo-upload" className="cursor-pointer flex flex-col items-center justify-center gap-2">
                    {photoUploaded ? (
                      <div className="flex flex-col items-center">
                        <div className="w-12 h-12 bg-emerald-500/20 text-emerald-500 rounded-full flex items-center justify-center mb-2 border border-emerald-500/30">
                          <Check className="w-6 h-6" />
                        </div>
                        <span className="text-sm text-emerald-400 font-medium">Baseline Photo Uploaded</span>
                        <span className="text-xs text-neutral-500 mt-1">Ready for comparison tracking</span>
                      </div>
                    ) : (
                      <>
                        <Upload className="w-8 h-8 text-neutral-400" />
                        <span className="text-sm text-neutral-300 font-medium">Drag starting photo here, or browse</span>
                        <span className="text-[11px] text-neutral-500">Supports JPG, PNG (Simulated Secure Vault)</span>
                      </>
                    )}
                  </label>
                </div>

                {/* Protocol Preview Box */}
                <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 space-y-3">
                  <div className="flex items-center gap-2 text-yellow-500 text-xs font-semibold uppercase tracking-wider">
                    <Sparkles className="w-4 h-4" />
                    <span>Live Protocol Estimation</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="bg-neutral-900 border border-neutral-800/60 p-2.5 rounded-lg">
                      <div className="text-neutral-400 text-[10px] uppercase font-semibold">Calories</div>
                      <div className="text-sm font-bold text-white mt-1">{calculateMacros().calories} kcal</div>
                    </div>
                    <div className="bg-neutral-900 border border-neutral-800/60 p-2.5 rounded-lg">
                      <div className="text-neutral-400 text-[10px] uppercase font-semibold">Protein Target</div>
                      <div className="text-sm font-bold text-white mt-1">{calculateMacros().protein}g</div>
                    </div>
                    <div className="bg-neutral-900 border border-neutral-800/60 p-2.5 rounded-lg">
                      <div className="text-neutral-400 text-[10px] uppercase font-semibold">Routine Focus</div>
                      <div className="text-sm font-bold text-white mt-1 capitalize">{formData.goal} Split</div>
                    </div>
                  </div>
                  <p className="text-[11px] text-neutral-400 leading-relaxed text-center">
                    Upon clicking 'Generate Anabolic Protocol', a customized PDF-style performance profile will be generated, unlocking your daily metrics and PR logging system.
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Form Actions */}
        <div className="flex items-center justify-between pt-8 border-t border-neutral-800/60 mt-8">
          {step > 1 ? (
            <button
              type="button"
              onClick={prevStep}
              className="px-5 py-2.5 rounded-lg border border-neutral-800 text-neutral-300 text-sm font-medium hover:bg-neutral-800 transition-colors flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
          ) : (
            <div />
          )}

          {step < 4 ? (
            <button
              type="button"
              onClick={nextStep}
              className="px-5 py-2.5 rounded-lg bg-yellow-500 text-black text-sm font-semibold hover:bg-yellow-400 transition-colors flex items-center gap-2 ml-auto"
            >
              <span>Continue</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="submit"
              className="px-6 py-2.5 rounded-lg bg-yellow-500 text-black text-sm font-bold hover:bg-yellow-400 transition-colors flex items-center gap-2 ml-auto shadow-lg shadow-yellow-500/10"
            >
              <Sparkles className="w-4 h-4" />
              <span>Generate Anabolic Protocol</span>
            </button>
          )}
        </div>
      </form>
    </div>
  );
}
