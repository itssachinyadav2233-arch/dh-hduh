/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { WorkoutLog, LoggedExercise, LoggedSet, FitnessGoal } from '../types';
import { DAILY_ROUTINES_BY_GOAL } from '../data';
import { Play, Square, Timer, Plus, Check, Award, Trophy, Dumbbell, AlertTriangle, Flame, RefreshCw, Zap } from 'lucide-react';

interface WorkoutLoggerProps {
  goal: FitnessGoal;
  streakDays: number;
  onWorkoutComplete: (duration: number) => void;
  onPrLogged: (exerciseName: string, weight: number, reps: number) => void;
  savedPrs: Array<{ id: string; exercise: string; weight: number; reps: number; date: string }>;
}

export default function WorkoutLogger({
  goal,
  streakDays,
  onWorkoutComplete,
  onPrLogged,
  savedPrs
}: WorkoutLoggerProps) {
  // Pull routine based on user's goal
  const defaultRoutine = DAILY_ROUTINES_BY_GOAL[goal] || DAILY_ROUTINES_BY_GOAL['bulk'];
  
  const [workoutActive, setWorkoutActive] = useState(false);
  const [duration, setDuration] = useState(0);
  const [routine, setRoutine] = useState<Omit<WorkoutLog, 'date' | 'id' | 'completed'>>({
    routineName: defaultRoutine.routineName,
    exercises: JSON.parse(JSON.stringify(defaultRoutine.exercises)) // deep copy
  });

  // Timer for set rest
  const [restSeconds, setRestSeconds] = useState(0);
  const [maxRest, setMaxRest] = useState(90); // 90s default rest
  const [restActive, setRestActive] = useState(false);

  // New Custom Exercise Builder
  const [showAddCustomEx, setShowAddCustomEx] = useState(false);
  const [customExName, setCustomExName] = useState('');
  const [customExCategory, setCustomExCategory] = useState('chest');

  // PR Form
  const [prExercise, setPrExercise] = useState('');
  const [prWeight, setPrWeight] = useState('');
  const [prReps, setPrReps] = useState('');
  const [prSuccessMsg, setPrSuccessMsg] = useState('');

  // Workout duration tracker
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (workoutActive) {
      interval = setInterval(() => {
        setDuration((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [workoutActive]);

  // Rest timer countdown
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (restActive && restSeconds > 0) {
      interval = setInterval(() => {
        setRestSeconds((prev) => prev - 1);
      }, 1000);
    } else if (restSeconds === 0) {
      setRestActive(false);
    }
    return () => clearInterval(interval);
  }, [restActive, restSeconds]);

  const handleStartWorkout = () => {
    setWorkoutActive(true);
    setDuration(0);
  };

  const handleSetToggle = (exIndex: number, setIndex: number) => {
    if (!workoutActive) return;

    const updatedRoutine = { ...routine };
    const currentSet = updatedRoutine.exercises[exIndex].sets[setIndex];
    const nextState = !currentSet.completed;
    
    currentSet.completed = nextState;
    setRoutine(updatedRoutine);

    if (nextState) {
      // Start rest timer
      setRestSeconds(maxRest);
      setRestActive(true);
    }
  };

  const handleSetChange = (exIndex: number, setIndex: number, field: 'weight' | 'reps', value: number) => {
    const updatedRoutine = { ...routine };
    updatedRoutine.exercises[exIndex].sets[setIndex][field] = value;
    setRoutine(updatedRoutine);
  };

  const handleAddSet = (exIndex: number) => {
    const updatedRoutine = { ...routine };
    const sets = updatedRoutine.exercises[exIndex].sets;
    const lastSet = sets[sets.length - 1] || { weight: 60, reps: 8 };
    sets.push({
      setNumber: sets.length + 1,
      weight: lastSet.weight,
      reps: lastSet.reps,
      completed: false
    });
    setRoutine(updatedRoutine);
  };

  const handleAddCustomExercise = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customExName.trim()) return;

    const newEx: LoggedExercise = {
      id: 'custom-' + Date.now(),
      name: customExName.trim(),
      category: customExCategory,
      sets: [
        { setNumber: 1, weight: 20, reps: 10, completed: false }
      ],
      notes: 'Custom exercise added by user.'
    };

    setRoutine((prev) => ({
      ...prev,
      exercises: [...prev.exercises, newEx]
    }));

    setCustomExName('');
    setShowAddCustomEx(false);
  };

  const handlePRSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const weightVal = parseFloat(prWeight);
    const repsVal = parseInt(prReps);
    if (!prExercise.trim() || !weightVal || !repsVal) return;

    onPrLogged(prExercise.trim(), weightVal, repsVal);
    setPrSuccessMsg(`🔥 PR Saved! ${prExercise}: ${weightVal}kg x ${repsVal} reps!`);
    
    setPrExercise('');
    setPrWeight('');
    setPrReps('');

    setTimeout(() => {
      setPrSuccessMsg('');
    }, 4000);
  };

  const handleFinishWorkout = () => {
    setWorkoutActive(false);
    const mins = Math.ceil(duration / 60);
    onWorkoutComplete(mins);
    // Reset completed states in routine for next session
    const resetExercises = routine.exercises.map((ex) => ({
      ...ex,
      sets: ex.sets.map((set) => ({ ...set, completed: false }))
    }));
    setRoutine({
      ...routine,
      exercises: resetExercises
    });
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainingSecs = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainingSecs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* COLUMN 1 & 2: ACTIVE LOGGER */}
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-yellow-500 text-xs font-semibold uppercase tracking-wider">ACTIVE LIFTING COMPANION</span>
            <h2 className="text-2xl font-bold text-white tracking-tight font-sans">{routine.routineName}</h2>
            <p className="text-xs text-neutral-400">Targeting hypertrophy parameters adjusted to your goal.</p>
          </div>

          <div className="flex items-center gap-3">
            {!workoutActive ? (
              <button
                onClick={handleStartWorkout}
                className="px-5 py-2.5 bg-yellow-500 text-black rounded-lg font-bold text-xs uppercase hover:bg-yellow-400 transition-colors flex items-center gap-2 shadow-lg shadow-yellow-500/15"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Begin Training</span>
              </button>
            ) : (
              <div className="flex items-center gap-4">
                <div className="bg-neutral-950 border border-neutral-800 px-4 py-2 rounded-lg text-center">
                  <span className="block text-[9px] text-neutral-500 uppercase font-semibold">Active Timer</span>
                  <span className="text-sm font-mono font-bold text-white">{formatTime(duration)}</span>
                </div>
                <button
                  onClick={handleFinishWorkout}
                  className="px-5 py-2.5 bg-red-500 text-white rounded-lg font-bold text-xs uppercase hover:bg-red-600 transition-colors flex items-center gap-2"
                >
                  <Square className="w-3.5 h-3.5 fill-current" />
                  <span>Complete & Log</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* REST TIMER COMPONENT */}
        <AnimatePresence>
          {restActive && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4 flex items-center justify-between gap-4 overflow-hidden"
            >
              <div className="flex items-center gap-3 text-yellow-500">
                <div className="w-8 h-8 rounded-full bg-yellow-500/10 flex items-center justify-center border border-yellow-500/20">
                  <Timer className="w-4 h-4 animate-spin" style={{ animationDuration: '3s' }} />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider">Intra-Set Recovery Active</h4>
                  <p className="text-[10px] text-neutral-400">Keep deep breaths to re-oxygenate hemoglobin fibers.</p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-lg font-mono font-black text-white">{restSeconds}s</div>
                <button
                  onClick={() => setRestActive(false)}
                  className="bg-yellow-500 text-black text-[10px] font-bold uppercase px-3 py-1.5 rounded-md hover:bg-yellow-400"
                >
                  Skip
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* EXERCISES WORKOUT SHEET */}
        <div className="space-y-6">
          {routine.exercises.map((ex, exIdx) => {
            const isFinished = ex.sets.length > 0 && ex.sets.every(s => s.completed);
            return (
              <div
                key={ex.id}
                className={`bg-neutral-900 border rounded-2xl p-5 transition-all ${
                  isFinished ? 'border-emerald-500/30 bg-emerald-500/[0.01]' : 'border-neutral-800'
                }`}
              >
                <div className="flex items-center justify-between pb-3 border-b border-neutral-800 mb-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-white">{ex.name}</h3>
                      {isFinished && (
                        <span className="bg-emerald-500/15 text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-500/20 flex items-center gap-1">
                          <Check className="w-3 h-3" />
                          <span>ALL SETS HIT</span>
                        </span>
                      )}
                    </div>
                    {ex.notes && <p className="text-[11px] text-neutral-400 mt-0.5">{ex.notes}</p>}
                  </div>

                  <span className="text-[10px] bg-neutral-950 border border-neutral-800 text-neutral-400 px-2.5 py-1 rounded-full font-bold uppercase">
                    {ex.category}
                  </span>
                </div>

                {/* SETS TABLE */}
                <div className="space-y-3">
                  <div className="grid grid-cols-12 gap-2 text-center text-[10px] uppercase font-bold text-neutral-500">
                    <div className="col-span-2 text-left">Set</div>
                    <div className="col-span-4">Load (kg)</div>
                    <div className="col-span-4">Reps</div>
                    <div className="col-span-2">Hit</div>
                  </div>

                  {ex.sets.map((set, setIdx) => (
                    <div
                      key={setIdx}
                      className={`grid grid-cols-12 gap-2 items-center text-center p-2 rounded-lg border transition-all ${
                        set.completed
                          ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-300'
                          : 'bg-neutral-950 border-neutral-800/60'
                      }`}
                    >
                      <div className="col-span-2 text-left font-mono font-bold text-sm text-neutral-300 pl-1">
                        #{set.setNumber}
                      </div>

                      <div className="col-span-4 flex items-center justify-center gap-1">
                        <input
                          type="number"
                          value={set.weight}
                          onChange={(e) => handleSetChange(exIdx, setIdx, 'weight', parseFloat(e.target.value) || 0)}
                          disabled={set.completed || !workoutActive}
                          className="w-16 bg-neutral-900 border border-neutral-800/80 rounded px-2 py-1 text-center font-bold text-xs text-white focus:outline-none focus:border-yellow-500 disabled:opacity-75 disabled:border-transparent"
                        />
                        <span className="text-[10px] text-neutral-500">kg</span>
                      </div>

                      <div className="col-span-4 flex items-center justify-center gap-1">
                        <input
                          type="number"
                          value={set.reps}
                          onChange={(e) => handleSetChange(exIdx, setIdx, 'reps', parseInt(e.target.value) || 0)}
                          disabled={set.completed || !workoutActive}
                          className="w-12 bg-neutral-900 border border-neutral-800/80 rounded px-2 py-1 text-center font-bold text-xs text-white focus:outline-none focus:border-yellow-500 disabled:opacity-75 disabled:border-transparent"
                        />
                        <span className="text-[10px] text-neutral-500">reps</span>
                      </div>

                      <div className="col-span-2 flex justify-center">
                        <button
                          type="button"
                          disabled={!workoutActive}
                          onClick={() => handleSetToggle(exIdx, setIdx)}
                          className={`w-7 h-7 rounded-md flex items-center justify-center border transition-all ${
                            set.completed
                              ? 'bg-emerald-500 border-emerald-400 text-black'
                              : 'bg-neutral-900 border-neutral-800 text-neutral-500 hover:text-white hover:border-neutral-600'
                          } disabled:opacity-40 disabled:cursor-not-allowed`}
                        >
                          <Check className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Add a set capability */}
                {workoutActive && (
                  <button
                    onClick={() => handleAddSet(exIdx)}
                    className="w-full mt-3 py-1.5 rounded-lg border border-dashed border-neutral-800 text-neutral-500 hover:text-neutral-300 hover:border-neutral-700 text-xs font-bold uppercase flex items-center justify-center gap-1 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Working Set</span>
                  </button>
                )}
              </div>
            );
          })}
        </div>

        {/* CUSTOM EXERCISE BUILDER */}
        {workoutActive && (
          <div>
            {!showAddCustomEx ? (
              <button
                onClick={() => setShowAddCustomEx(true)}
                className="w-full py-3 rounded-xl border border-dashed border-neutral-800 hover:border-neutral-600 text-xs font-bold text-neutral-400 hover:text-white uppercase transition-all flex items-center justify-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>Inject Custom Exercise into Split</span>
              </button>
            ) : (
              <form onSubmit={handleAddCustomExercise} className="bg-neutral-950 border border-neutral-800 rounded-2xl p-5 space-y-4">
                <h4 className="text-xs font-extrabold text-white uppercase tracking-wider">Configure Custom Movement</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    required
                    value={customExName}
                    onChange={(e) => setCustomExName(e.target.value)}
                    placeholder="e.g. Incline Dumbbell Hammer Curl"
                    className="bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none"
                  />
                  <select
                    value={customExCategory}
                    onChange={(e) => setCustomExCategory(e.target.value)}
                    className="bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none"
                  >
                    <option value="chest">Chest</option>
                    <option value="back">Back</option>
                    <option value="legs">Legs</option>
                    <option value="shoulders">Shoulders</option>
                    <option value="arms">Arms</option>
                    <option value="core">Core</option>
                  </select>
                </div>
                <div className="flex gap-2">
                  <button
                    type="submit"
                    className="flex-1 py-1.5 bg-yellow-500 text-black text-xs font-bold rounded-lg hover:bg-yellow-400 uppercase"
                  >
                    Add Exercise
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowAddCustomEx(false)}
                    className="px-3 bg-neutral-800 border border-neutral-700 text-white text-xs rounded-lg hover:bg-neutral-700"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>

      {/* COLUMN 3: GAMIFICATION, STREAKS, AND PERSONAL RECORDS (PR) */}
      <div className="space-y-6">
        {/* STREAK BOOSTER */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-4 relative overflow-hidden" id="streak-tracker">
          <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-orange-500/10 rounded-full blur-2xl" />
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-sans">Consistency Engine</h3>
            <Flame className="w-5 h-5 text-orange-500 animate-bounce" />
          </div>

          <div className="flex items-center gap-4">
            <span className="text-4xl font-extrabold text-white font-mono">{streakDays}</span>
            <div>
              <span className="block text-xs font-bold text-orange-400">Current Day Streak</span>
              <span className="text-[10px] text-neutral-400">Keep logging check-ins to boost anabolic streak multiplier.</span>
            </div>
          </div>

          <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800/60 flex items-center gap-2">
            <Zap className="w-4 h-4 text-yellow-500" />
            <span className="text-[10px] text-neutral-400 leading-snug">
              Streak active! You are qualifying for the <strong className="text-white font-semibold">Consistent Titan Badge</strong>.
            </span>
          </div>
        </div>

        {/* PR TRACKER & LOG FORM */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-4">
          <div className="flex items-center gap-2 pb-1.5 border-b border-neutral-800">
            <Trophy className="w-5 h-5 text-yellow-500" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-sans">Personal Record Vault</h3>
          </div>

          <form onSubmit={handlePRSubmit} className="space-y-3">
            <div>
              <label className="block text-[10px] text-neutral-400 uppercase font-semibold mb-1">Exercise Name</label>
              <input
                type="text"
                required
                value={prExercise}
                onChange={(e) => setPrExercise(e.target.value)}
                placeholder="e.g., Incline Bench Press"
                className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-3 py-2 text-xs focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[10px] text-neutral-400 uppercase font-semibold mb-1">Max Load (kg)</label>
                <input
                  type="number"
                  required
                  value={prWeight}
                  onChange={(e) => setPrWeight(e.target.value)}
                  placeholder="100"
                  className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-3 py-2 text-xs focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-[10px] text-neutral-400 uppercase font-semibold mb-1">Reps</label>
                <input
                  type="number"
                  required
                  value={prReps}
                  onChange={(e) => setPrReps(e.target.value)}
                  placeholder="5"
                  className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-3 py-2 text-xs focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-yellow-500 text-black text-[11px] font-bold uppercase rounded-lg hover:bg-yellow-400 transition-colors"
            >
              Log New PR
            </button>
          </form>

          {prSuccessMsg && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-3 bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 rounded-lg text-xs leading-snug"
            >
              {prSuccessMsg}
            </motion.div>
          )}

          {/* ACTIVE PRS LIST */}
          <div className="space-y-2 pt-2">
            <h4 className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest">Logged Achievements</h4>
            {savedPrs.length === 0 ? (
              <p className="text-[11px] text-neutral-500 italic">No historical PRs recorded yet. Push boundaries!</p>
            ) : (
              <div className="space-y-2 max-h-44 overflow-y-auto pr-1">
                {savedPrs.map((pr) => (
                  <div key={pr.id} className="bg-neutral-950 p-2.5 rounded-lg border border-neutral-800/80 flex items-center justify-between">
                    <div>
                      <span className="block text-xs font-bold text-white">{pr.exercise}</span>
                      <span className="text-[9px] text-neutral-500">{pr.date}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="bg-yellow-500/10 text-yellow-500 text-xs font-mono font-bold px-2 py-0.5 rounded border border-yellow-500/20">
                        {pr.weight}kg
                      </span>
                      <span className="text-[10px] text-neutral-400">x {pr.reps}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* TROPHIES AND BADGES */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-4">
          <div className="flex items-center gap-2 pb-1.5 border-b border-neutral-800">
            <Award className="w-5 h-5 text-yellow-500" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-sans">Virtual Trophies</h3>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {[
              { title: 'Gold Pioneer', desc: 'Finished Onboarding', earned: true, icon: Trophy },
              { title: 'Consistent Titan', desc: 'Workout check-in streak', earned: streakDays >= 3, icon: Flame },
              { title: 'Barbell Beast', desc: 'Bench PR logged (>80kg)', earned: savedPrs.some(p => p.weight >= 80), icon: Dumbbell },
              { title: 'Macro Commander', desc: '100% daily diet adherence', earned: true, icon: Zap }
            ].map((b, i) => {
              const Icon = b.icon;
              return (
                <div
                  key={i}
                  className={`p-3 border rounded-xl flex flex-col items-center text-center transition-all ${
                    b.earned
                      ? 'bg-yellow-500/5 border-yellow-500/30 text-white'
                      : 'bg-neutral-950 border-neutral-800/60 opacity-50'
                  }`}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1.5 ${
                    b.earned ? 'bg-yellow-500/20 text-yellow-500' : 'bg-neutral-900 text-neutral-600'
                  }`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <h5 className="text-[11px] font-bold leading-tight">{b.title}</h5>
                  <p className="text-[9px] text-neutral-400 leading-normal mt-0.5">{b.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
