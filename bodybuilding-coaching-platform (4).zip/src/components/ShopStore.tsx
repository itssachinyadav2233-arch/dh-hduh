/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Product, MembershipTier } from '../types';
import { PRODUCTS } from '../data';
import { ShoppingCart, ShieldCheck, Tag, Ticket, Download, FileText, Check, ArrowRight, Star, CreditCard, Lock, Info } from 'lucide-react';

interface ShopStoreProps {
  currentTier: MembershipTier;
  onUpgradeTier: (tier: MembershipTier) => void;
}

export default function ShopStore({ currentTier, onUpgradeTier }: ShopStoreProps) {
  const [isAnnual, setIsAnnual] = useState(false);
  const [category, setCategory] = useState<'all' | 'programs' | 'supplements' | 'apparel'>('all');
  const [cart, setCart] = useState<Product[]>([]);
  const [discountCode, setDiscountCode] = useState('');
  const [discountMultiplier, setDiscountMultiplier] = useState(1.0); // No discount
  const [appliedCodeMsg, setAppliedCodeMsg] = useState('');
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [checkoutProduct, setCheckoutProduct] = useState<Product | null>(null);
  const [checkoutTier, setCheckoutTier] = useState<MembershipTier | null>(null);
  const [checkoutStep, setCheckoutStep] = useState<'info' | 'payment' | 'success'>('info');
  const [checkoutName, setCheckoutName] = useState('');
  const [checkoutCard, setCheckoutCard] = useState('');
  const [checkoutCoupon, setCheckoutCoupon] = useState('');
  const [invoiceId, setInvoiceId] = useState('');
  const [purchasedPrograms, setPurchasedPrograms] = useState<string[]>([]);

  const handleApplyCoupon = (code: string) => {
    const formatted = code.trim().toUpperCase();
    if (formatted === 'SHRED20') {
      setDiscountMultiplier(0.8);
      setAppliedCodeMsg('Coupon SHRED20 applied: 20% OFF your total!');
    } else if (formatted === 'MASS15') {
      setDiscountMultiplier(0.85);
      setAppliedCodeMsg('Coupon MASS15 applied: 15% OFF your total!');
    } else {
      setAppliedCodeMsg('Invalid coupon code.');
    }
  };

  const getSubPrice = (base: number) => {
    const price = isAnnual ? base * 0.8 : base; // 20% discount for annual
    return price.toFixed(2);
  };

  const filteredProducts = category === 'all' 
    ? PRODUCTS 
    : PRODUCTS.filter(p => p.category === category);

  const startProductCheckout = (product: Product) => {
    setCheckoutProduct(product);
    setCheckoutTier(null);
    setCheckoutStep('info');
    setInvoiceId('INV-' + Math.floor(100000 + Math.random() * 900000));
    setIsCheckoutOpen(true);
  };

  const startSubscriptionCheckout = (tier: MembershipTier) => {
    setCheckoutTier(tier);
    setCheckoutProduct(null);
    setCheckoutStep('info');
    setInvoiceId('SUB-' + Math.floor(100000 + Math.random() * 900000));
    setIsCheckoutOpen(true);
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (checkoutStep === 'info') {
      setCheckoutStep('payment');
    } else if (checkoutStep === 'payment') {
      // Complete transaction
      setCheckoutStep('success');
      if (checkoutTier) {
        onUpgradeTier(checkoutTier);
      }
      if (checkoutProduct && checkoutProduct.category === 'programs') {
        setPurchasedPrograms(prev => [...prev, checkoutProduct.id]);
      }
    }
  };

  const totalCheckoutPrice = () => {
    let base = 0;
    if (checkoutProduct) {
      base = checkoutProduct.price;
    } else if (checkoutTier) {
      if (checkoutTier === 'premium') base = isAnnual ? 39 * 12 : 49;
      if (checkoutTier === 'elite') base = isAnnual ? 239 * 12 : 299;
    }
    return (base * discountMultiplier).toFixed(2);
  };

  // Simulated digital PDF files
  const downloadRoutinePDF = (programId: string) => {
    const program = PRODUCTS.find(p => p.id === programId);
    if (!program) return;
    
    const markdownContent = `
========================================
ANABOLIC PERFORMANCE GUIDE - DIGITAL SHEETS
Program: ${program.name}
Authorized Copy: Certified Client
========================================

BLOCK 1: PREgressive OVERLOAD
* Focus on eccentric deceleration (3-4 seconds).
* Record starting weights and attempt micro-loading.

WEEK 1 SPLIT SCHEDULE:
- Day 1: Heavy Incline Bench + Chest Extortions (Chest/Arms)
- Day 2: Hypertrophy Posterior Chain - RDL focus (Legs/Back)
- Day 3: ACTIVE RECOVERY CARDIO & Mobility
- Day 4: Vertical Pull focus (Weighted Pull-ups)
- Day 5: Front/Side Deltoid Blast (Shoulders/Core)
- Day 6: Quad Focused Leg Destroyer (Hack Squats)
- Day 7: rest & hyper-recovery

NUTRITIONAL PRINCIPLES:
- Keep protein at a minimum of 2.2g per kg.
- Consume 45g carbs + 25g whey 45 minutes pre-workout.
- Re-hydrate with high minerals post-workout.

SECURED SSL ENCRYPTED FILE TRANSMISSION APPROVED.
    `;
    
    const blob = new Blob([markdownContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${program.name.toLowerCase().replace(/\\s+/g, '_')}_routine.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-12">
      {/* SECTION 1: MEMBERSHIP SUBSCRIPTIONS */}
      <section className="bg-neutral-900 border border-neutral-800 rounded-2xl p-8 space-y-8 relative overflow-hidden" id="subscriptions-pricing">
        <div className="absolute top-0 right-0 w-64 h-64 bg-yellow-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="text-center space-y-3">
          <span className="text-yellow-500 text-xs font-semibold uppercase tracking-wider bg-yellow-500/10 border border-yellow-500/20 px-3 py-1 rounded-full">
            MEMBERSHIP TIERS
          </span>
          <h2 className="text-3xl font-extrabold text-white tracking-tight">Select Your Aesthetic Protocol</h2>
          <p className="text-sm text-neutral-400 max-w-lg mx-auto">
            Choose a tier and unlock daily coaching check-ins, fully-featured exercise library lists, and professional bodybuilding sets tracking.
          </p>

          {/* Toggle Button for annual billing */}
          <div className="flex items-center justify-center gap-3 pt-4">
            <span className={`text-xs font-medium ${!isAnnual ? 'text-white' : 'text-neutral-500'}`}>Monthly Billing</span>
            <button
              onClick={() => setIsAnnual(!isAnnual)}
              className="w-12 h-6 rounded-full bg-neutral-800 border border-neutral-700 p-0.5 transition-colors relative"
            >
              <div
                className={`w-5 h-5 rounded-full bg-yellow-500 transition-transform duration-300 ${
                  isAnnual ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
            <span className={`text-xs font-medium flex items-center gap-1.5 ${isAnnual ? 'text-yellow-500' : 'text-neutral-500'}`}>
              Annual Saving (20% OFF)
              <span className="bg-yellow-500/15 border border-yellow-500/30 text-[10px] text-yellow-400 px-1.5 py-0.2 rounded-md font-bold">SAVE</span>
            </span>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* FREE PLAN */}
          <div className={`border rounded-2xl p-6 flex flex-col justify-between transition-all bg-neutral-950/60 ${
            currentTier === 'free' ? 'border-neutral-500/40' : 'border-neutral-800/80'
          }`}>
            <div className="space-y-4">
              <div className="space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-widest text-neutral-500">Tier 01</span>
                <h3 className="text-lg font-bold text-white">Bronze Affiliate</h3>
                <p className="text-xs text-neutral-400">Basic tracker and profile access.</p>
              </div>
              <div className="flex items-baseline text-white">
                <span className="text-3xl font-extrabold">$0</span>
                <span className="text-xs text-neutral-500 font-medium ml-1">/ lifetime</span>
              </div>
              <ul className="space-y-2 text-xs text-neutral-300 pt-4 border-t border-neutral-900">
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-yellow-500" />
                  <span>Onboarding Goal Quiz</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-yellow-500" />
                  <span>Interactive Macro Calculator</span>
                </li>
                <li className="flex items-center gap-2 text-neutral-500 line-through">
                  <span>Daily Set/Rep Workout Logging</span>
                </li>
                <li className="flex items-center gap-2 text-neutral-500 line-through">
                  <span>Complete Video Exercise Library</span>
                </li>
              </ul>
            </div>
            <div className="pt-6">
              <button
                disabled
                className="w-full py-2.5 rounded-lg border border-neutral-800 text-neutral-500 text-xs font-bold uppercase cursor-not-allowed"
              >
                {currentTier === 'free' ? 'Current Protocol' : 'Included'}
              </button>
            </div>
          </div>

          {/* PREMIUM COACHED PLAN */}
          <div className={`border rounded-2xl p-6 flex flex-col justify-between transition-all relative overflow-hidden ${
            currentTier === 'premium' ? 'border-yellow-500 bg-yellow-500/5 shadow-yellow-500/5' : 'border-yellow-500/30 bg-neutral-950/80 hover:border-yellow-500/60'
          }`}>
            <div className="absolute top-0 right-0 bg-yellow-500 text-black text-[9px] font-black uppercase px-2.5 py-1 rounded-bl-lg tracking-wider">
              Popular
            </div>
            <div className="space-y-4">
              <div className="space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-widest text-yellow-500">Tier 02</span>
                <h3 className="text-lg font-bold text-white">Gold Coach Pro</h3>
                <p className="text-xs text-neutral-400">Our flagship progressive training protocol.</p>
              </div>
              <div className="flex items-baseline text-white">
                <span className="text-3xl font-extrabold">${getSubPrice(49)}</span>
                <span className="text-xs text-neutral-500 font-medium ml-1">/ {isAnnual ? 'yr' : 'mo'}</span>
              </div>
              <ul className="space-y-2 text-xs text-neutral-300 pt-4 border-t border-neutral-900">
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-yellow-500" />
                  <span>All Bronze features</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-yellow-500" />
                  <span className="font-medium text-white">Interactive Workout Logger</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-yellow-500" />
                  <span>Set-by-set target prompts</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-yellow-500" />
                  <span>Full Exercise Video Vault</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-yellow-500" />
                  <span>Progress charts & history</span>
                </li>
              </ul>
            </div>
            <div className="pt-6">
              {currentTier === 'premium' ? (
                <button
                  disabled
                  className="w-full py-2.5 rounded-lg bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 text-xs font-bold uppercase"
                >
                  Active Plan
                </button>
              ) : (
                <button
                  onClick={() => startSubscriptionCheckout('premium')}
                  className="w-full py-2.5 rounded-lg bg-yellow-500 text-black text-xs font-extrabold uppercase hover:bg-yellow-400 transition-colors"
                >
                  Acquire Gold Protocol
                </button>
              )}
            </div>
          </div>

          {/* ELITE OLYMPIAN PLAN */}
          <div className={`border rounded-2xl p-6 flex flex-col justify-between transition-all bg-neutral-950/60 ${
            currentTier === 'elite' ? 'border-amber-500 bg-amber-500/5' : 'border-neutral-800/80 hover:border-neutral-700'
          }`}>
            <div className="space-y-4">
              <div className="space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-widest text-amber-500">Tier 03</span>
                <h3 className="text-lg font-bold text-white">IFBB Olympian Elite</h3>
                <p className="text-xs text-neutral-400">Custom tailored posing feedback & coach messaging.</p>
              </div>
              <div className="flex items-baseline text-white">
                <span className="text-3xl font-extrabold">${getSubPrice(299)}</span>
                <span className="text-xs text-neutral-500 font-medium ml-1">/ {isAnnual ? 'yr' : 'mo'}</span>
              </div>
              <ul className="space-y-2 text-xs text-neutral-300 pt-4 border-t border-neutral-900">
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-yellow-500" />
                  <span>All Gold Coach features</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-yellow-500" />
                  <span className="font-semibold text-white">Direct Chat with IFBB Pro</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-yellow-500" />
                  <span>Weekly video biomechanics review</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-yellow-500" />
                  <span>Free access to all standalone Programs</span>
                </li>
              </ul>
            </div>
            <div className="pt-6">
              {currentTier === 'elite' ? (
                <button
                  disabled
                  className="w-full py-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-500 text-xs font-bold uppercase"
                >
                  Active Olympian Plan
                </button>
              ) : (
                <button
                  onClick={() => startSubscriptionCheckout('elite')}
                  className="w-full py-2.5 rounded-lg border border-neutral-800 text-white text-xs font-bold uppercase hover:bg-neutral-800 transition-colors"
                >
                  Go Elite Olympian
                </button>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 2: DIGITAL STORE & SHOP */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-white tracking-tight font-sans">E-Commerce & Digital Materials</h2>
            <p className="text-sm text-neutral-400">Acquire premium programs, top-tier recovery accessories, and athletic attire.</p>
          </div>

          {/* Filtering */}
          <div className="flex items-center gap-2 bg-neutral-900 border border-neutral-800/80 p-1.5 rounded-xl self-start sm:self-center">
            {(['all', 'programs', 'supplements', 'apparel'] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase transition-all ${
                  category === cat
                    ? 'bg-yellow-500 text-black'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((prod) => {
            const isOwned = purchasedPrograms.includes(prod.id);
            return (
              <motion.div
                key={prod.id}
                layout
                className="bg-neutral-900 border border-neutral-800/80 rounded-2xl overflow-hidden hover:border-neutral-700/80 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="relative h-44 bg-neutral-950 overflow-hidden group">
                    <img
                      src={prod.image}
                      alt={prod.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-3 left-3 flex gap-1.5 flex-wrap">
                      {prod.tags?.map((tag) => (
                        <span key={tag} className="bg-neutral-950/80 text-[10px] text-white font-semibold px-2 py-0.5 rounded-md border border-white/10">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="p-5 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-yellow-500 uppercase tracking-wider">{prod.category}</span>
                      <div className="flex items-center gap-1 text-xs font-semibold text-yellow-500">
                        <Star className="w-3.5 h-3.5 fill-current" />
                        <span>{prod.rating.toFixed(1)}</span>
                      </div>
                    </div>

                    <h3 className="text-base font-bold text-white leading-snug">{prod.name}</h3>
                    <p className="text-xs text-neutral-400 leading-relaxed line-clamp-2">{prod.description}</p>

                    <div className="pt-2">
                      <ul className="space-y-1 text-[11px] text-neutral-400">
                        {prod.features?.slice(0, 2).map((feat, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <span className="text-yellow-500 mt-0.5">•</span>
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="p-5 pt-0 border-t border-neutral-800/40 mt-3 flex items-center justify-between gap-4">
                  <div className="flex flex-col">
                    <span className="text-[10px] text-neutral-500 uppercase font-medium">Value</span>
                    <span className="text-lg font-extrabold text-white">${prod.price}</span>
                  </div>

                  {isOwned ? (
                    <button
                      onClick={() => downloadRoutinePDF(prod.id)}
                      className="px-4 py-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/20 transition-all text-xs font-bold flex items-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download Guide</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => startProductCheckout(prod)}
                      className="px-4 py-2 rounded-lg bg-yellow-500 text-black hover:bg-yellow-400 transition-all text-xs font-bold flex items-center gap-1.5"
                    >
                      <span>Acquire Guide</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* CHECKOUT MODAL */}
      <AnimatePresence>
        {isCheckoutOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCheckoutOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl relative z-10"
            >
              <div className="bg-neutral-950 p-5 border-b border-neutral-800/60 flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <Lock className="w-4 h-4 text-yellow-500" />
                    <span>SSL Encrypted Checkout</span>
                  </h3>
                  <p className="text-[11px] text-neutral-500">Invoice: {invoiceId}</p>
                </div>
                <div className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-400 bg-emerald-400/10 border border-emerald-400/20 px-2.5 py-1 rounded-full">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>SECURE GATEWAY</span>
                </div>
              </div>

              <form onSubmit={handleCheckoutSubmit} className="p-6 space-y-5">
                {checkoutStep === 'info' && (
                  <div className="space-y-4">
                    <div className="bg-neutral-950/60 p-4 border border-neutral-800 rounded-xl space-y-2">
                      <span className="text-[10px] text-neutral-500 uppercase font-semibold">Item to Acquire</span>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold text-white">
                          {checkoutProduct ? checkoutProduct.name : `Gold Coach Sub (${checkoutTier === 'elite' ? 'Olympian' : 'Standard'})`}
                        </span>
                        <span className="text-sm font-extrabold text-white">
                          ${checkoutProduct ? checkoutProduct.price : checkoutTier === 'elite' ? (isAnnual ? 239 * 12 : 299) : (isAnnual ? 39 * 12 : 49)}
                        </span>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="block text-[11px] font-semibold text-neutral-400 uppercase mb-1">Your Full Name</label>
                        <input
                          type="text"
                          required
                          value={checkoutName}
                          onChange={(e) => setCheckoutName(e.target.value)}
                          placeholder="Arnold Schwarzenegger"
                          className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-3.5 py-2.5 text-sm focus:outline-none focus:border-yellow-500 transition-colors"
                        />
                      </div>

                      <div className="flex items-center gap-2 pt-1">
                        <input
                          type="checkbox"
                          required
                          id="gdpr-chk"
                          className="w-4 h-4 rounded border-neutral-800 bg-neutral-950 text-yellow-500 focus:ring-yellow-500"
                        />
                        <label htmlFor="gdpr-chk" className="text-[11px] text-neutral-400 leading-none cursor-pointer">
                          I consent to the secure caching of my stats (GDPR & HIPAA compliant)
                        </label>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2.5 bg-yellow-500 text-black text-xs font-extrabold uppercase rounded-lg hover:bg-yellow-400 transition-colors flex items-center justify-center gap-1"
                    >
                      <span>Proceed to Payments</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                {checkoutStep === 'payment' && (
                  <div className="space-y-4">
                    <div className="bg-neutral-950 border border-neutral-800/80 rounded-xl p-4 flex items-center gap-3">
                      <CreditCard className="w-5 h-5 text-yellow-500" />
                      <div className="flex-1">
                        <span className="block text-xs font-bold text-white">Direct Card Entry</span>
                        <span className="text-[10px] text-neutral-500">Visa, Mastercard, AMEX verified</span>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="block text-[11px] font-semibold text-neutral-400 uppercase mb-1">Card Number (Mock)</label>
                        <input
                          type="text"
                          required
                          value={checkoutCard}
                          onChange={(e) => setCheckoutCard(e.target.value)}
                          placeholder="4111 •••• •••• 1111"
                          maxLength={19}
                          className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-3.5 py-2.5 text-sm focus:outline-none focus:border-yellow-500 transition-colors font-mono"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] font-semibold text-neutral-400 uppercase mb-1">Expiry</label>
                          <input
                            type="text"
                            required
                            placeholder="MM / YY"
                            className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-3.5 py-2.5 text-sm focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-semibold text-neutral-400 uppercase mb-1">CVC</label>
                          <input
                            type="password"
                            required
                            placeholder="•••"
                            maxLength={3}
                            className="w-full bg-neutral-950 border border-neutral-800 text-white rounded-lg px-3.5 py-2.5 text-sm focus:outline-none"
                          />
                        </div>
                      </div>

                      {/* Coupon input */}
                      <div className="pt-2">
                        <label className="block text-[11px] font-semibold text-neutral-400 uppercase mb-1">Add Promo Coupon</label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={checkoutCoupon}
                            onChange={(e) => setCheckoutCoupon(e.target.value)}
                            placeholder="e.g. SHRED20"
                            className="flex-1 bg-neutral-950 border border-neutral-800 text-white rounded-lg px-3 py-2 text-xs focus:outline-none uppercase font-mono"
                          />
                          <button
                            type="button"
                            onClick={() => handleApplyCoupon(checkoutCoupon)}
                            className="px-3 bg-neutral-800 border border-neutral-700 text-white rounded-lg text-xs font-bold hover:bg-neutral-700"
                          >
                            Apply
                          </button>
                        </div>
                        {appliedCodeMsg && (
                          <span className="block text-[10px] text-yellow-500 mt-1">{appliedCodeMsg}</span>
                        )}
                      </div>
                    </div>

                    <div className="pt-3 border-t border-neutral-800/40 flex items-center justify-between">
                      <span className="text-xs text-neutral-400 font-medium">Charged Amount</span>
                      <span className="text-lg font-black text-white">${totalCheckoutPrice()}</span>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2.5 bg-yellow-500 text-black text-xs font-extrabold uppercase rounded-lg hover:bg-yellow-400 transition-colors flex items-center justify-center gap-1 shadow-lg shadow-yellow-500/10"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>Complete Secure Payment</span>
                    </button>
                  </div>
                )}

                {checkoutStep === 'success' && (
                  <div className="text-center py-6 space-y-5">
                    <div className="w-16 h-16 bg-emerald-500/20 text-emerald-500 rounded-full flex items-center justify-center mx-auto border border-emerald-500/30">
                      <Check className="w-8 h-8" />
                    </div>

                    <div className="space-y-1">
                      <h4 className="text-lg font-bold text-white">Transaction Verified</h4>
                      <p className="text-xs text-neutral-400">Your invoice has been compiled and cataloged.</p>
                    </div>

                    {/* Simple Invoice Card */}
                    <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 text-left font-mono text-[11px] text-neutral-400 space-y-1">
                      <div className="flex justify-between font-bold text-white pb-1 border-b border-neutral-800/60 mb-2">
                        <span>INVOICE SUMMARY</span>
                        <span>{invoiceId}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Customer:</span>
                        <span className="text-white">{checkoutName || 'Athlete Client'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Description:</span>
                        <span className="text-white">
                          {checkoutProduct ? checkoutProduct.name : `Gold Coach Tier`}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Status:</span>
                        <span className="text-emerald-400 font-bold">PAID • APPROVED</span>
                      </div>
                      <div className="flex justify-between font-bold text-white pt-1 border-t border-neutral-800/40 mt-2">
                        <span>Total Paid:</span>
                        <span>${totalCheckoutPrice()}</span>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      {checkoutProduct && checkoutProduct.category === 'programs' && (
                        <button
                          type="button"
                          onClick={() => downloadRoutinePDF(checkoutProduct.id)}
                          className="flex-1 py-2.5 bg-emerald-500 text-black text-xs font-bold uppercase rounded-lg hover:bg-emerald-400 flex items-center justify-center gap-1"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Download Program Guide</span>
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => setIsCheckoutOpen(false)}
                        className="flex-1 py-2.5 bg-neutral-800 text-white text-xs font-bold uppercase rounded-lg hover:bg-neutral-700"
                      >
                        Return to Platform
                      </button>
                    </div>
                  </div>
                )}
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
