/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ExerciseLibraryItem, Product, CommunityPost, WorkoutLog } from './types';

export const EXERCISE_LIBRARY: ExerciseLibraryItem[] = [
  {
    id: 'ex-1',
    name: 'Barbell Incline Bench Press',
    category: 'chest',
    description: 'A classic compound lift targeting the upper pectorals and anterior deltoids.',
    targetMuscles: ['Upper Chest', 'Triceps', 'Front Delts'],
    difficulty: 'intermediate',
    instructions: [
      'Lie on an incline bench (30-45 degrees) with your feet flat on the floor.',
      'Grip the barbell slightly wider than shoulder-width.',
      'Unrack the bar and lower it with control to your upper chest.',
      'Push the bar back up forcefully to full lockout while keeping your elbows tucked at ~45 degrees.'
    ]
  },
  {
    id: 'ex-2',
    name: 'Dumbbell Flat Bench Flyes',
    category: 'chest',
    description: 'An isolation exercise designed to stretch and squeeze the pectoralis major.',
    targetMuscles: ['Chest', 'Anterior Deltoids'],
    difficulty: 'beginner',
    instructions: [
      'Lie flat on a bench holding dumbbells above your chest with palms facing each other.',
      'Lower the weights out to the sides in a wide arc, keeping a slight bend in your elbows.',
      'Go down until you feel a deep stretch in your chest muscles.',
      'Squeeze your chest to bring the weights back to the starting position.'
    ]
  },
  {
    id: 'ex-3',
    name: 'Barbell Romanian Deadlift (RDL)',
    category: 'legs',
    description: 'An elite hinge movement focusing on hamstring, glute, and spinal erector development.',
    targetMuscles: ['Hamstrings', 'Glutes', 'Lower Back'],
    difficulty: 'intermediate',
    instructions: [
      'Stand with feet hip-width apart, holding a barbell in front of your thighs.',
      'Hinge at your hips, pushing them back as far as possible while keeping knees slightly bent.',
      'Lower the barbell close to your shins, maintaining a perfectly flat back and packed neck.',
      'Squeeze your glutes and hamstrings to stand back up to starting position.'
    ]
  },
  {
    id: 'ex-4',
    name: 'Hack Squat',
    category: 'legs',
    description: 'A machine-guided squat movement that minimizes lower back load to isolate the quadriceps.',
    targetMuscles: ['Quadriceps', 'Glutes'],
    difficulty: 'intermediate',
    instructions: [
      'Position your back flat against the pad and place shoulders firmly under the pads.',
      'Place feet shoulder-width apart on the platform with toes slightly outward.',
      'Release the safety catches and lower yourself until your thighs are at or below parallel.',
      'Drive through your heels to return to the starting position.'
    ]
  },
  {
    id: 'ex-5',
    name: 'Weighted Pull-Ups',
    category: 'back',
    description: 'The king of vertical pulls, building lat width and upper-back thickness.',
    targetMuscles: ['Lats', 'Upper Back', 'Biceps'],
    difficulty: 'advanced',
    instructions: [
      'Secure a weight plate using a dip belt or hold a dumbbell between your feet.',
      'Grip the pull-up bar with hands wider than shoulder-width, palms facing away.',
      'Pull your chest up towards the bar by driving your elbows down and back.',
      'Control your descent slowly until your arms are fully extended.'
    ]
  },
  {
    id: 'ex-6',
    name: 'Meadows Row',
    category: 'back',
    description: 'A unilateral pronated row using a landmine barbell setup to target upper lat and trap thickness.',
    targetMuscles: ['Lats', 'Rear Delts', 'Rhomboids'],
    difficulty: 'intermediate',
    instructions: [
      'Stand perpendicular to a landmine barbell. Lean forward with a flat back.',
      'Grip the end of the sleeve with an overhand (pronated) grip.',
      'Row the bar up by pulling your elbow high, aiming to drive it slightly outward to hit upper back fibers.',
      'Lower the bar slowly to a full stretch.'
    ]
  },
  {
    id: 'ex-7',
    name: 'Seated Dumbbell Shoulder Press',
    category: 'shoulders',
    description: 'A robust vertical press focusing on front and lateral deltoid mass.',
    targetMuscles: ['Anterior Deltoids', 'Triceps', 'Upper Chest'],
    difficulty: 'intermediate',
    instructions: [
      'Sit on an upright bench supporting dumbbells at shoulder height.',
      'Press the dumbbells straight overhead until your arms are fully locked.',
      'Lower the weights back down under control to just below chin height.'
    ]
  },
  {
    id: 'ex-8',
    name: 'Incline Dumbbell Curl',
    category: 'arms',
    description: 'Places the biceps on an intense stretch, highlighting development of the long head.',
    targetMuscles: ['Biceps Brachii', 'Brachialis'],
    difficulty: 'beginner',
    instructions: [
      'Sit on an incline bench at ~45 degrees with dumbbells hanging at arm\'s length.',
      'Keep your elbows locked back and curl the weights up, supinating your wrists at the top.',
      'Squeeze the biceps, then slowly lower the weights back to full arm extension.'
    ]
  }
];

export const PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    name: '12-Week Hypertrophy Mastery',
    price: 49.99,
    rating: 4.9,
    description: 'The ultimate guide to packing on raw muscle mass using advanced training splits, progressive overload logs, and customizable nutrition templates.',
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=600&q=80',
    category: 'programs',
    tags: ['Muscle Mass', '12 Weeks', 'Intermediate-Advanced'],
    features: ['Fully detailed 4, 5, and 6-day splits', 'Science-backed volume parameters', 'Calculated macro sheets included', 'Direct coach support access']
  },
  {
    id: 'prod-2',
    name: 'Vascular Shredding Protocol',
    price: 39.99,
    rating: 4.8,
    description: 'Designed to accelerate fat loss while maintaining maximum strength. Features high-intensity cardio protocols, refeed guides, and stage prep secrets.',
    image: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?auto=format&fit=crop&w=600&q=80',
    category: 'programs',
    tags: ['Fat Loss', '8 Weeks', 'All Levels'],
    features: ['Refeed and diet break schematics', 'LISS and HIIT progression guides', 'Full exercise database access', 'Posing tutorial videos']
  },
  {
    id: 'prod-3',
    name: 'Anabolic Pre-Workout Peak V2',
    price: 54.99,
    rating: 4.9,
    description: 'Surgically formulated pre-workout with 8g L-Citrulline, 3.2g Beta-Alanine, and 400mg Alpha-GPC for mind-blowing muscle pumps and laser focus.',
    image: 'https://images.unsplash.com/photo-1579758629938-03607ccdbaba?auto=format&fit=crop&w=600&q=80',
    category: 'supplements',
    tags: ['Pump', 'Focus', 'Stimulant-Heavy'],
    features: ['Nitric oxide supercharger (8g Citrulline)', 'Intense cognitive focus matrix', 'No heavy fillers, 100% transparent label']
  },
  {
    id: 'prod-4',
    name: 'Micronized Pure Creatine 500g',
    price: 29.99,
    rating: 5.0,
    description: '100% Pure Creapure Micronized Creatine Monohydrate. Increases muscular power, cellular hydration, and ATP regeneration.',
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=600&q=80',
    category: 'supplements',
    tags: ['Power', 'Hydration', 'Unflavored'],
    features: ['Creapure premium quality grade', 'Ultra-micronized for instant mixing', 'Increases explosive power and lift capacity']
  },
  {
    id: 'prod-5',
    name: 'Anabolic Aesthetics Gym Stringer',
    price: 24.99,
    rating: 4.7,
    description: 'Ultra-light, sweat-wicking drop armhole tank. Tailored to accent your shoulders, back, and upper chest taper.',
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=600&q=80',
    category: 'apparel',
    tags: ['Gym Apparel', 'Athletic Fit'],
    features: ['95% Premium cotton, 5% elastane', 'Engineered back stringer design', 'Reinforced stitching for heavy lifts']
  }
];

export const COMMUNITY_POSTS: CommunityPost[] = [
  {
    id: 'post-1',
    author: 'Coach Marcus',
    role: 'Head Bodybuilding Coach (IFBB Pro)',
    avatar: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=150&q=80',
    content: 'Just a reminder to all my athletes checking in today: do not compromise your eccentric control to squeeze out 2 extra reps! Control the negative, stretch at the bottom, and explode on the concentric. That is where hypertrophy lives.',
    likes: 42,
    likedByUser: false,
    timestamp: '2 hours ago',
    replies: [
      {
        id: 'reply-1',
        author: 'Alex Carter',
        content: 'Spot on coach! Swapped to a 3-second negative on my Hack Squats and the quad pump is insane.',
        timestamp: '1 hour ago'
      },
      {
        id: 'reply-2',
        author: 'Sarah Jenkins',
        content: 'Is this applicable to overhead triceps movements too? My elbows tend to flare.',
        timestamp: '45 mins ago'
      }
    ]
  },
  {
    id: 'post-2',
    author: 'Elena Rostova',
    role: 'Wellness Athlete',
    avatar: 'https://images.unsplash.com/photo-1548690312-e3b507d8c110?auto=format&fit=crop&w=150&q=80',
    content: 'Hit a massive PR on Romanian Deadlifts today! 125kg for 8 reps. Following the cutting protocol and somehow keeping my strength. The carb refeed day yesterday worked wonders.',
    likes: 29,
    likedByUser: false,
    timestamp: '5 hours ago',
    replies: [
      {
        id: 'reply-3',
        author: 'Coach Marcus',
        content: 'Phenomenal progress, Elena. Staying strong during a deficit indicates your muscle retention is near 100%. Keep crushing.',
        timestamp: '4 hours ago'
      }
    ]
  },
  {
    id: 'post-3',
    author: 'Jason Miller',
    role: 'Classic Physique Competitor',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80',
    content: 'W10 Check-in. Weight sitting at 82.5kg. Looking dry and vascular. Prep brain is starting to hit, but we are 3 weeks out from the regional show. Let’s get this gold!',
    likes: 56,
    likedByUser: false,
    timestamp: '1 day ago',
    replies: []
  }
];

export const HISTORICAL_WEIGHT_MOCK = [
  { day: 'Day 1', weight: 85.2 },
  { day: 'Day 3', weight: 84.8 },
  { day: 'Day 5', weight: 84.5 },
  { day: 'Day 7', weight: 84.1 },
  { day: 'Day 9', weight: 83.9 },
  { day: 'Day 11', weight: 83.4 },
  { day: 'Day 13', weight: 83.0 },
  { day: 'Day 14', weight: 82.8 }
];

export const HISTORICAL_MACRO_MOCK = [
  { name: 'Protein', actual: 185, target: 190 },
  { name: 'Carbs', actual: 230, target: 220 },
  { name: 'Fats', actual: 62, target: 65 }
];

export const DAILY_ROUTINES_BY_GOAL: Record<string, Omit<WorkoutLog, 'date' | 'id' | 'completed'>> = {
  bulk: {
    routineName: 'Hypertrophy Hyper-Drive (Push A)',
    exercises: [
      {
        id: 'bulk-ex-1',
        name: 'Barbell Incline Bench Press',
        category: 'chest',
        sets: [
          { setNumber: 1, weight: 80, reps: 8, completed: false },
          { setNumber: 2, weight: 80, reps: 7, completed: false },
          { setNumber: 3, weight: 75, reps: 9, completed: false }
        ],
        notes: 'Keep shoulders retracted. Target RPE 8-9 on final set.'
      },
      {
        id: 'bulk-ex-2',
        name: 'Seated Dumbbell Shoulder Press',
        category: 'shoulders',
        sets: [
          { setNumber: 1, weight: 30, reps: 10, completed: false },
          { setNumber: 2, weight: 28, reps: 11, completed: false }
        ],
        notes: 'Press in a straight line, lock elbows slowly.'
      },
      {
        id: 'bulk-ex-3',
        name: 'Incline Dumbbell Flyes',
        category: 'chest',
        sets: [
          { setNumber: 1, weight: 18, reps: 12, completed: false },
          { setNumber: 2, weight: 16, reps: 15, completed: false }
        ],
        notes: 'Exaggerated stretch, slow eccentric.'
      },
      {
        id: 'bulk-ex-4',
        name: 'Dumbbell Lateral Raises',
        category: 'shoulders',
        sets: [
          { setNumber: 1, weight: 12, reps: 15, completed: false },
          { setNumber: 2, weight: 12, reps: 15, completed: false },
          { setNumber: 3, weight: 10, reps: 20, completed: false }
        ],
        notes: 'Slight hinge, raise dumbbells out and slightly forward.'
      }
    ]
  },
  cut: {
    routineName: 'Vascular Shred & Retain (Pull A)',
    exercises: [
      {
        id: 'cut-ex-1',
        name: 'Weighted Pull-Ups',
        category: 'back',
        sets: [
          { setNumber: 1, weight: 10, reps: 6, completed: false },
          { setNumber: 2, weight: 5, reps: 8, completed: false },
          { setNumber: 3, weight: 0, reps: 12, completed: false }
        ],
        notes: 'Hang for full lat stretch at bottom of every rep.'
      },
      {
        id: 'cut-ex-2',
        name: 'Meadows Row',
        category: 'back',
        sets: [
          { setNumber: 1, weight: 40, reps: 10, completed: false },
          { setNumber: 2, weight: 40, reps: 10, completed: false }
        ],
        notes: 'Drive with elbow. Let lat stretch fully before pulling.'
      },
      {
        id: 'cut-ex-3',
        name: 'Dumbbell Hammer Curls',
        category: 'arms',
        sets: [
          { setNumber: 1, weight: 16, reps: 12, completed: false },
          { setNumber: 2, weight: 14, reps: 12, completed: false }
        ],
        notes: 'Focuses on brachioradialis and biceps forearm thickness.'
      },
      {
        id: 'cut-ex-4',
        name: 'Face Pulls (Cable)',
        category: 'shoulders',
        sets: [
          { setNumber: 1, weight: 20, reps: 15, completed: false },
          { setNumber: 2, weight: 20, reps: 15, completed: false }
        ],
        notes: 'Pull to eyes, separate hands to squeeze rear delts.'
      }
    ]
  },
  recomp: {
    routineName: 'Recomposition Power-Builder (Legs A)',
    exercises: [
      {
        id: 'recomp-ex-1',
        name: 'Hack Squat',
        category: 'legs',
        sets: [
          { setNumber: 1, weight: 100, reps: 8, completed: false },
          { setNumber: 2, weight: 100, reps: 8, completed: false },
          { setNumber: 3, weight: 80, reps: 12, completed: false }
        ],
        notes: 'Go deep to parallel. Control the negative.'
      },
      {
        id: 'recomp-ex-2',
        name: 'Barbell Romanian Deadlift (RDL)',
        category: 'legs',
        sets: [
          { setNumber: 1, weight: 90, reps: 10, completed: false },
          { setNumber: 2, weight: 90, reps: 10, completed: false }
        ],
        notes: 'Hinge hips backwards, flat back, squeeze glutes at top.'
      },
      {
        id: 'recomp-ex-3',
        name: 'Seated Leg Extensions',
        category: 'legs',
        sets: [
          { setNumber: 1, weight: 50, reps: 15, completed: false },
          { setNumber: 2, weight: 45, reps: 15, completed: false }
        ],
        notes: 'Pause at the top peak contraction for 1 second.'
      },
      {
        id: 'recomp-ex-4',
        name: 'Standing Calf Raises',
        category: 'legs',
        sets: [
          { setNumber: 1, weight: 40, reps: 15, completed: false },
          { setNumber: 2, weight: 40, reps: 15, completed: false }
        ],
        notes: '2-second stretch at bottom, 1-second squeeze at top.'
      }
    ]
  }
};
