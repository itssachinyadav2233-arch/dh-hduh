/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type FitnessGoal = 'bulk' | 'cut' | 'recomp';
export type ExperienceLevel = 'beginner' | 'intermediate' | 'advanced';
export type MembershipTier = 'free' | 'premium' | 'elite';

export interface UserProfile {
  name: string;
  email: string;
  age: number;
  gender: string;
  height: number; // in cm
  weight: number; // in kg
  targetWeight: number; // in kg
  bodyFat?: number; // percentage
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'very_active';
  goal: FitnessGoal;
  experienceLevel: ExperienceLevel;
  injuries: string;
  primaryFocus: string;
  completedOnboarding: boolean;
  membershipTier: MembershipTier;
  macroTargets: {
    protein: number; // in grams
    carbs: number; // in grams
    fats: number; // in grams
    calories: number;
    water: number; // in ml
  };
  streakDays: number;
  lastCheckInDate?: string; // YYYY-MM-DD
}

export interface LoggedSet {
  setNumber: number;
  weight: number; // in kg
  reps: number;
  completed: boolean;
}

export interface LoggedExercise {
  id: string;
  name: string;
  category: string;
  sets: LoggedSet[];
  notes?: string;
  videoUrl?: string;
}

export interface WorkoutLog {
  id: string;
  date: string; // YYYY-MM-DD
  routineName: string;
  exercises: LoggedExercise[];
  completed: boolean;
  durationMinutes?: number;
}

export interface MacroLog {
  date: string; // YYYY-MM-DD
  protein: number;
  carbs: number;
  fats: number;
  calories: number;
  water: number; // ml
}

export interface WeightLog {
  date: string; // YYYY-MM-DD
  weight: number;
}

export interface CommunityPost {
  id: string;
  author: string;
  role: string;
  avatar: string;
  content: string;
  likes: number;
  likedByUser?: boolean;
  timestamp: string;
  replies?: Array<{
    id: string;
    author: string;
    content: string;
    timestamp: string;
  }>;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  rating: number;
  description: string;
  image: string;
  category: 'programs' | 'supplements' | 'apparel';
  tags?: string[];
  features?: string[];
}

export interface ExerciseLibraryItem {
  id: string;
  name: string;
  category: 'chest' | 'back' | 'legs' | 'shoulders' | 'arms' | 'core';
  description: string;
  instructions: string[];
  targetMuscles: string[];
  difficulty: ExperienceLevel;
}
